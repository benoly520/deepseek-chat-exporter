(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
let activeEffect = null;
const effectStack = [];
let activeOwner = null;
const ownerStack = [];
const ERROR_HANDLER = Symbol("plain.errorHandler");
function untracked(fn) {
  const prev = activeEffect;
  activeEffect = null;
  try {
    return fn();
  } finally {
    activeEffect = prev;
  }
}
function cleanup(effect2) {
  effect2.deps.forEach((s) => s.subs.delete(effect2));
  effect2.deps.clear();
}
function effect(fn, owner) {
  const e = {
    deps: /* @__PURE__ */ new Set(),
    fn,
    disposed: false,
    // 创建时快照下来的 owner 链：运行期抛错时用它找最近的 ErrorBoundary
    // （不能用运行时的 ownerStack —— effect 重跑时那条栈早就空了）
    ownerChain: ownerStack.length ? ownerStack.slice() : null,
    run() {
      if (e.disposed)
        return;
      cleanup(e);
      activeEffect = e;
      effectStack.push(e);
      try {
        return fn();
      } catch (err) {
        const chain = e.ownerChain || [];
        for (let i = chain.length - 1; i >= 0; i--) {
          const h = chain[i][ERROR_HANDLER];
          if (h) {
            try {
              h(err);
            } catch (_) {
              break;
            }
            return;
          }
        }
        throw err;
      } finally {
        effectStack.pop();
        activeEffect = effectStack[effectStack.length - 1] || null;
      }
    },
    dispose() {
      if (e.disposed)
        return;
      e.disposed = true;
      cleanup(e);
      queue.delete(e);
    }
  };
  if (activeOwner)
    activeOwner.add(e.dispose);
  e.run();
  if (e.disposed)
    return e;
  return e;
}
const queue = /* @__PURE__ */ new Set();
function signal(initial) {
  const s = { value: initial, subs: /* @__PURE__ */ new Set() };
  const read = function() {
    if (activeEffect) {
      s.subs.add(activeEffect);
      activeEffect.deps.add(s);
    }
    return s.value;
  };
  read.peek = () => s.value;
  read.set = function(next) {
    const v = typeof next === "function" ? next(s.value) : next;
    if (Object.is(v, s.value))
      return v;
    s.value = v;
    const subs = Array.from(s.subs);
    subs.forEach((e) => {
      if (!e.disposed)
        e.run();
    });
    return v;
  };
  read.subs = s.subs;
  return read;
}
function computed(fn, owner) {
  const out = signal(void 0);
  effect(() => out.set(fn()));
  return out;
}
function stringify(v) {
  if (v === null || v === void 0)
    return "";
  if (typeof v === "boolean")
    return v ? "true" : "false";
  return String(v);
}
function withOwner(ownerSet, fn) {
  const prev = activeOwner;
  activeOwner = ownerSet;
  ownerStack.push(ownerSet);
  try {
    return fn();
  } finally {
    ownerStack.pop();
    activeOwner = prev;
  }
}
function getOwner() {
  return activeOwner;
}
function resolve(v) {
  return typeof v === "function" ? v() : v;
}
function rowProxy(getRow) {
  return new Proxy({}, {
    get(_t, prop) {
      const row = getRow();
      if (row === null || row === void 0)
        return void 0;
      if (prop === Symbol.toPrimitive || prop === "toString") {
        return () => String(row);
      }
      return row[prop];
    },
    set(_t, prop, value) {
      const row = getRow();
      if (row)
        row[prop] = value;
      return true;
    },
    has(_t, prop) {
      const row = getRow();
      return row ? prop in row : false;
    },
    ownKeys() {
      const row = getRow();
      return row ? Reflect.ownKeys(row) : [];
    },
    getOwnPropertyDescriptor(_t, prop) {
      const row = getRow();
      if (!row)
        return void 0;
      return { configurable: true, enumerable: true, value: row[prop] };
    }
  });
}
const SVG_NS = "http://www.w3.org/2000/svg";
const MATH_NS = "http://www.w3.org/1998/Math/MathML";
const SVG_TAGS = /* @__PURE__ */ new Set([
  "svg",
  "g",
  "path",
  "circle",
  "ellipse",
  "rect",
  "line",
  "polyline",
  "polygon",
  "text",
  "tspan",
  "defs",
  "use",
  "symbol",
  "linearGradient",
  "radialGradient",
  "stop",
  "clipPath",
  "image",
  "marker",
  "pattern",
  "mask",
  "filter",
  "feGaussianBlur",
  "feOffset",
  "feMerge",
  "feMergeNode",
  "feColorMatrix",
  "feBlend",
  "feComposite",
  "metadata",
  "switch",
  "view",
  "desc"
]);
const MATH_TAGS = /* @__PURE__ */ new Set([
  "math",
  "mi",
  "mn",
  "mo",
  "ms",
  "mtext",
  "mspace",
  "mrow",
  "mfrac",
  "msqrt",
  "mroot",
  "msup",
  "msub",
  "msubsup",
  "mover",
  "munder",
  "mmultiscripts",
  "mtable",
  "mtr",
  "mtd",
  "mlabeledtr"
]);
function nsForTag(tag) {
  if (SVG_TAGS.has(tag))
    return SVG_NS;
  if (MATH_TAGS.has(tag))
    return MATH_NS;
  return null;
}
let ctx = null;
function getHydrationCtx() {
  return ctx;
}
function suspendHydrate() {
  const saved = ctx;
  ctx = null;
  return () => {
    ctx = saved;
  };
}
function detach(node) {
  const p = node.parentNode;
  if (p)
    p.removeChild(node);
}
function peek() {
  if (!ctx)
    return null;
  return ctx.index < ctx.list.length ? ctx.list[ctx.index] : null;
}
function step() {
  if (ctx)
    ctx.index++;
}
function skipWhitespace() {
  while (ctx) {
    const n = peek();
    if (n && n.nodeType === 3 && (n.nodeValue || "").trim() === "") {
      step();
      continue;
    }
    break;
  }
}
function claimPair(openLabel, closeLabel) {
  if (!ctx)
    return null;
  skipWhitespace();
  const start = peek();
  if (!(start && start.nodeType === 8 && start.nodeValue === openLabel))
    return null;
  const content = [];
  let close = null;
  let sib = start.nextSibling;
  while (sib) {
    if (sib.nodeType === 8 && sib.nodeValue === closeLabel) {
      close = sib;
      break;
    }
    content.push(sib);
    sib = sib.nextSibling;
  }
  if (!close)
    return null;
  skipFlatTo(close);
  detach(start);
  content.forEach((c) => detach(c));
  detach(close);
  return { start, end: close, content };
}
function skipFlatTo(node) {
  if (!ctx)
    return;
  let i = ctx.index;
  while (i < ctx.list.length && ctx.list[i] !== node)
    i++;
  if (i >= ctx.list.length)
    return;
  let j = i + 1;
  while (j < ctx.list.length && isDescendant(ctx.list[j], node))
    j++;
  ctx.index = j;
}
function isDescendant(a, b) {
  let p = a.parentNode;
  while (p) {
    if (p === b)
      return true;
    p = p.parentNode;
  }
  return false;
}
const registry = /* @__PURE__ */ new Set();
let nextId = 0;
let currentModuleId = null;
function hmrRegister(record) {
  const id = record.id ?? currentModuleId ?? `__plain__${nextId++}`;
  const rec = { id, ...record };
  registry.add(rec);
  return () => registry.delete(rec);
}
let pending = [];
function __ref(el, fn) {
  if (typeof fn !== "function") {
    throw new TypeError("[plain] ref 需要一个函数：ref={(el) => { … }}；元素连入文档后会用该元素调用它一次");
  }
  const owner = getOwner();
  const entry = { el, fn, owner };
  pending.push(entry);
  if (owner && typeof owner.add === "function") {
    owner.add(() => {
      const i = pending.indexOf(entry);
      if (i >= 0)
        pending.splice(i, 1);
    });
  }
}
function flushRefs() {
  if (!pending.length)
    return;
  const run = [];
  const rest = [];
  for (const entry of pending) {
    if (entry.el && entry.el.isConnected)
      run.push(entry);
    else
      rest.push(entry);
  }
  pending = rest;
  let firstError = null;
  for (const entry of run) {
    try {
      const call = () => entry.fn(entry.el);
      const cleanup2 = entry.owner ? withOwner(entry.owner, call) : call();
      if (typeof cleanup2 === "function") {
        if (entry.owner && typeof entry.owner.add === "function") {
          entry.owner.add(cleanup2);
        }
      }
    } catch (err) {
      if (firstError === null)
        firstError = err;
    }
  }
  if (firstError !== null)
    throw firstError;
}
function createEl(tag, parent) {
  const ns = nsForTag(tag);
  if (ns)
    return document.createElementNS(ns, tag);
  const pns = parent == null ? void 0 : parent.namespaceURI;
  if (pns === SVG_NS)
    return document.createElementNS(SVG_NS, tag);
  if (pns === MATH_NS)
    return document.createElementNS(MATH_NS, tag);
  return document.createElement(tag);
}
function mount(target, node) {
  const el = document.querySelector(target);
  if (!el)
    throw new Error(`[plain] mount 找不到目标：${target}`);
  const isComp = typeof node === "function";
  const startMark = document.createComment(`${A}root]`);
  const endMark = document.createComment(`${A}/root]`);
  el.appendChild(startMark);
  el.appendChild(endMark);
  let current = [];
  let cleanups = /* @__PURE__ */ new Set();
  const render = () => {
    const n = isComp ? withOwner(cleanups, () => node()) : node;
    const nodes = toNodes(n);
    syncRange(startMark, endMark, nodes);
    current = nodes;
  };
  render();
  const unmount = () => {
    cleanups.forEach((f) => f());
    cleanups.clear();
    current.forEach((x) => x.remove && x.remove());
    startMark.remove && startMark.remove();
    endMark.remove && endMark.remove();
  };
  if (isComp) {
    const unregister = hmrRegister({
      container: el,
      comp: node,
      // 热替换时只回收旧 effect（DOM 交给 rebuild 的 syncRange 做最小重排）
      dispose: () => {
        cleanups.forEach((f) => f());
        cleanups.clear();
        cleanups = /* @__PURE__ */ new Set();
      },
      rebuild: (comp) => {
        node = comp;
        render();
      }
    });
    return () => {
      unregister();
      unmount();
    };
  }
  return unmount;
}
function toNodes(v) {
  if (v === null || v === void 0 || typeof v === "boolean")
    return [];
  if (Array.isArray(v))
    return v.flatMap(toNodes);
  if (v.nodeType === 11)
    return Array.from(v.childNodes).flatMap(toNodes);
  if (v.nodeType)
    return [v];
  return [document.createTextNode(stringify(v))];
}
function markers(parent, open, close) {
  const ctx2 = getHydrationCtx();
  if (ctx2) {
    const pair = claimPair(open, close);
    if (pair) {
      parent.appendChild(pair.start);
      for (const c of pair.content)
        parent.appendChild(c);
      parent.appendChild(pair.end);
      return [pair.start, pair.end];
    }
  }
  const doc = (parent == null ? void 0 : parent.ownerDocument) || globalThis.document;
  const start = doc.createComment(open);
  const end = doc.createComment(close);
  parent.appendChild(start);
  parent.appendChild(end);
  return [start, end];
}
const A = "plain-";
function place(parent, node) {
  if (!node)
    return node;
  const list = node.__plainSlot ? toNodes(node.fragment) : toNodes(node);
  list.forEach((n) => parent.appendChild(n));
  flushRefs();
  return node;
}
function syncRange(start, end, next) {
  const parent = start.parentNode;
  if (!parent)
    return;
  const cur = [];
  let n = start.nextSibling;
  while (n && n !== end) {
    cur.push(n);
    n = n.nextSibling;
  }
  if (getHydrationCtx()) {
    reconcileHydrate(start, end, cur, next);
    flushRefs();
    return;
  }
  cur.forEach((x) => {
    if (next.indexOf(x) === -1 && x.remove)
      x.remove();
  });
  let ref = start.nextSibling;
  for (const want of next) {
    if (ref === want) {
      ref = want.nextSibling;
      continue;
    }
    parent.insertBefore(want, ref === null ? end : ref);
  }
  flushRefs();
}
function reconcileHydrate(start, end, cur, next) {
  const parent = start.parentNode;
  if (!parent)
    return;
  const n = Math.min(cur.length, next.length);
  for (let i = 0; i < n; i++) {
    if (sameKind(cur[i], next[i])) {
      inPlaceUpdate(cur[i], next[i]);
    } else {
      parent.insertBefore(next[i], cur[i]);
      if (cur[i].remove)
        cur[i].remove();
    }
  }
  for (let i = n; i < cur.length; i++) {
    if (cur[i].remove)
      cur[i].remove();
  }
  for (let i = n; i < next.length; i++) {
    parent.insertBefore(next[i], end);
  }
}
function sameKind(a, b) {
  if (!a || !b)
    return false;
  if (a === b)
    return true;
  if (a.nodeType === 3 && b.nodeType === 3)
    return true;
  if (a.nodeType === 1 && b.nodeType === 1 && String(a.tagName).toLowerCase() === String(b.tagName).toLowerCase()) {
    return true;
  }
  return false;
}
function inPlaceUpdate(a, b) {
  if (a === b)
    return;
  if (a.nodeType === 3 && b.nodeType === 3) {
    if (a.nodeValue !== b.nodeValue)
      a.nodeValue = b.nodeValue;
    return;
  }
  if (a.nodeType === 1 && b.nodeType === 1) {
    const aAttrs = a.attributes || [];
    const bAttrs = b.attributes || [];
    const bNames = /* @__PURE__ */ new Set();
    for (const at of Array.from(bAttrs)) {
      bNames.add(at.name);
      if (a.getAttribute(at.name) !== at.value)
        a.setAttribute(at.name, at.value);
    }
    for (const at of Array.from(aAttrs)) {
      if (!bNames.has(at.name))
        a.removeAttribute(at.name);
    }
    syncChildren(a, b);
  }
}
function syncChildren(a, b) {
  const want = Array.from(b.childNodes);
  const cur = Array.from(a.childNodes);
  cur.forEach((c) => {
    if (want.indexOf(c) === -1 && c.remove)
      c.remove();
  });
  let ref = a.firstChild;
  for (const w of want) {
    if (ref === w) {
      ref = w.nextSibling;
      continue;
    }
    a.insertBefore(w, ref);
  }
}
function insert(parent, get, owner) {
  const [start, end] = markers(parent, `${A}[`, `${A}]`);
  let cleanups = null;
  effect(() => {
    if (cleanups) {
      cleanups.forEach((f) => f());
      cleanups.clear();
    }
    const set = /* @__PURE__ */ new Set();
    let v;
    let built = [];
    const resume = suspendHydrate();
    try {
      withOwner(set, () => {
        v = get();
      });
      built = toNodes(v);
    } finally {
      resume();
    }
    cleanups = set;
    syncRange(start, end, built);
  });
}
function when(parent, getCond, thenFn, elseFn, owner) {
  const [start, end] = markers(parent, `${A}?`, `${A}/?`);
  let currentKey = null;
  let cleanups = null;
  effect(() => {
    const cond = getCond();
    const key = cond ? "then" : "else";
    if (currentKey === key)
      return;
    if (cleanups) {
      cleanups.forEach((f) => f());
      cleanups.clear();
    }
    currentKey = key;
    const set = /* @__PURE__ */ new Set();
    let node = null;
    let built = [];
    const resume = suspendHydrate();
    try {
      withOwner(set, () => {
        const branch = cond ? thenFn : elseFn;
        node = branch ? branch() : null;
      });
      built = toNodes(node);
    } finally {
      resume();
    }
    cleanups = set;
    syncRange(start, end, built);
  });
}
function each(parent, getter, itemFn, keyFn, owner) {
  const [start, end] = markers(parent, `${A}#`, `${A}/#`);
  let rows = [];
  const buildRow = (item, index) => {
    const rowSignal = signal(item);
    const cleanups = /* @__PURE__ */ new Set();
    let built = null;
    let nodes = [];
    const resume = suspendHydrate();
    try {
      withOwner(cleanups, () => {
        built = itemFn(rowProxy(() => rowSignal()), index);
      });
      nodes = toNodes(built);
    } finally {
      resume();
    }
    return { key: void 0, rowSignal, cleanups, nodes };
  };
  const dropRow = (row) => {
    row.cleanups.forEach((f) => f());
    row.cleanups.clear();
    row.nodes.forEach((n) => n.remove && n.remove());
    row.nodes = [];
  };
  effect(() => {
    const arr = getter() || [];
    if (typeof keyFn !== "function") {
      while (rows.length < arr.length)
        rows.push(buildRow(arr[rows.length], rows.length));
      while (rows.length > arr.length) {
        const r = rows.pop();
        if (r)
          dropRow(r);
      }
      for (let i = 0; i < arr.length; i++)
        rows[i].rowSignal.set(arr[i]);
    }
    const flat = [];
    rows.forEach((r) => r.nodes.forEach((n) => flat.push(n)));
    syncRange(start, end, flat);
  });
}
function formatEntry(e) {
  let line = `[${e.t}] [${e.lv.toUpperCase().padEnd(5)}] [${e.sc}] ${e.msg}`;
  if (e.data !== void 0) {
    try {
      line += ` ${JSON.stringify(e.data)}`;
    } catch {
      line += " [unserializable]";
    }
  }
  return line;
}
function formatAll(entries) {
  return entries.map(formatEntry).join("\n");
}
function consolePrint(lv, scope, msg, data) {
  const prefix = `[DeepSeek Exporter][${scope}]`;
  if (lv === "error") {
    console.error(prefix, msg, data ?? "");
  } else if (lv === "warn") {
    console.warn(prefix, msg, data ?? "");
  } else {
    console.log(prefix, msg, data ?? "");
  }
}
function createLocalLogger(scope, forward = false, sink) {
  const entries = [];
  function log(lv, msg, data) {
    var _a;
    const entry = { t: (/* @__PURE__ */ new Date()).toISOString(), lv, sc: scope, msg, data };
    entries.push(entry);
    if (entries.length > 500) entries.shift();
    consolePrint(lv, scope, msg, data);
    if (forward && typeof chrome !== "undefined" && ((_a = chrome.runtime) == null ? void 0 : _a.sendMessage)) {
      try {
        const msgObj = { type: "LOG_ENTRY", payload: entry };
        const result = chrome.runtime.sendMessage(msgObj);
        if (result && typeof result.catch === "function") {
          result.catch(() => {
          });
        }
      } catch {
      }
    }
  }
  return {
    debug: (msg, data) => log("debug", msg, data),
    info: (msg, data) => log("info", msg, data),
    warn: (msg, data) => log("warn", msg, data),
    error: (msg, data) => log("error", msg, data),
    /** 本上下文的内存日志（未持久化的部分） */
    entries
  };
}
function describeError(error) {
  if (error instanceof Error) {
    return error.message || error.name || "未知错误";
  }
  return String(error);
}
const status = signal({
  connected: false,
  currentSessionId: null,
  capturedSessions: 0,
  capturedMessages: 0,
  exporting: false,
  exportProgress: 0
});
const message = signal("");
const isError = signal(false);
const sessions = signal([]);
const selected = signal(/* @__PURE__ */ new Set());
const listLoading = signal(false);
const listLoaded = signal(0);
const logsText = signal("");
const extVersion = chrome.runtime.getManifest().version;
const confirmVisible = signal(false);
const confirmText = signal("");
let confirmResolve = null;
function confirmDialog(text) {
  confirmText.set(text);
  confirmVisible.set(true);
  return new Promise((resolve2) => {
    confirmResolve = resolve2;
  });
}
function answerConfirm(ok) {
  confirmVisible.set(false);
  const resolve2 = confirmResolve;
  confirmResolve = null;
  resolve2 == null ? void 0 : resolve2(ok);
}
function formatSessionDate(s) {
  const raw = s.updated_at ?? s.created_at;
  if (raw === void 0 || raw === null || raw === "") return "";
  let ms;
  if (typeof raw === "number") {
    ms = raw > 1e12 ? raw : raw * 1e3;
  } else if (/^\d+(\.\d+)?$/.test(raw)) {
    const n = Number(raw);
    ms = n > 1e12 ? n : n * 1e3;
  } else {
    const d2 = new Date(raw);
    if (isNaN(d2.getTime())) return "";
    ms = d2.getTime();
  }
  const d = new Date(ms);
  if (isNaN(d.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function buildLogsHeader(entryCount) {
  return `DeepSeek Chat Exporter v${extVersion} · 导出时间 ${(/* @__PURE__ */ new Date()).toLocaleString()} · 共 ${entryCount} 条日志`;
}
const progressTitle = computed(() => {
  const cur = status().exportCurrent;
  if (cur && cur.total > 0) {
    return `正在导出 ${cur.index}/${cur.total}：${cur.title}`;
  }
  return `导出中… ${status().exportProgress}%`;
});
const selectedCount = computed(() => selected().size);
async function fetchStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_STATUS" });
    if (response) {
      status.set(response);
    }
  } catch (error) {
    console.error("Failed to fetch status:", error);
  }
}
function showMessage(text, error) {
  message.set(text);
  isError.set(error);
}
async function loadList(force = false) {
  if (listLoading()) return;
  showMessage("", false);
  if (!force && sessions().length > 0) {
    return;
  }
  listLoading.set(true);
  listLoaded.set(0);
  try {
    const response = await chrome.runtime.sendMessage({ type: "LOAD_SESSIONS" });
    if (response == null ? void 0 : response.error) {
      showMessage(`加载会话列表失败: ${response.error}`, true);
      return;
    }
    const list = (response == null ? void 0 : response.sessions) || [];
    sessions.set(list);
    selected.set(new Set(list.map((s) => s.id)));
    showMessage(`已加载 ${list.length} 个会话`, false);
  } catch (error) {
    showMessage(`加载会话列表失败: ${describeError(error)}`, true);
  } finally {
    listLoading.set(false);
  }
}
function toggleSelect(id, checked) {
  const next = new Set(selected.peek());
  if (checked) {
    next.add(id);
  } else {
    next.delete(id);
  }
  selected.set(next);
}
function toggleAll() {
  const list = sessions.peek();
  if (selected.peek().size === list.length) {
    selected.set(/* @__PURE__ */ new Set());
  } else {
    selected.set(new Set(list.map((s) => s.id)));
  }
}
async function exportCurrent() {
  showMessage("", false);
  try {
    const response = await chrome.runtime.sendMessage({ type: "EXPORT_CURRENT" });
    if (!response) {
      throw new Error("无响应，请刷新页面后重试");
    }
    if (response.error) {
      showMessage(`导出失败: ${response.error}`, true);
    } else {
      showMessage(`导出成功: ${response.filename}`, false);
    }
  } catch (error) {
    showMessage(`导出失败: ${describeError(error)}`, true);
  } finally {
    const s = status.peek();
    status.set({ ...s, exporting: false, exportProgress: 0, exportCurrent: null });
  }
}
async function exportSelected() {
  const ids = Array.from(selected.peek());
  if (ids.length === 0) {
    showMessage("请先勾选要导出的会话", true);
    return;
  }
  showMessage("", false);
  try {
    const response = await chrome.runtime.sendMessage({
      type: "EXPORT_SELECTED",
      payload: { sessionIds: ids }
    });
    if (!response) {
      throw new Error("无响应，请刷新页面后重试");
    }
    if (response.error) {
      showMessage(`导出失败: ${response.error}`, true);
    } else {
      showMessage(`导出成功: ${response.filename} (${response.count} 个会话)`, false);
    }
  } catch (error) {
    showMessage(`导出失败: ${describeError(error)}`, true);
  } finally {
    const s = status.peek();
    status.set({ ...s, exporting: false, exportProgress: 0, exportCurrent: null });
  }
}
async function deleteSelected() {
  const ids = Array.from(selected.peek());
  if (ids.length === 0) {
    showMessage("请先勾选要删除的会话", true);
    return;
  }
  if (!status.peek().deleteTemplateReady) {
    showMessage(
      "删除接口尚未学习：请先在 DeepSeek 页面上手动删除任意一个会话，扩展会自动捕获该操作",
      true
    );
    return;
  }
  if (!await confirmDialog(
    `即将永久删除 ${ids.length} 个会话，此操作不可恢复！确认继续？`
  )) {
    return;
  }
  showMessage("", false);
  try {
    const response = await chrome.runtime.sendMessage({
      type: "DELETE_SESSIONS",
      payload: { sessionIds: ids }
    });
    if (!response) {
      throw new Error("无响应，请刷新页面后重试");
    }
    if (response.error) {
      showMessage(`删除失败: ${response.error}`, true);
    } else {
      showMessage(`删除完成: 成功 ${response.ok} 个，失败 ${response.failed} 个`, response.failed > 0);
      const deleted = new Set(ids);
      sessions.set(sessions.peek().filter((s) => !deleted.has(s.id)));
      selected.set(/* @__PURE__ */ new Set());
    }
  } catch (error) {
    showMessage(`删除失败: ${describeError(error)}`, true);
  } finally {
    const s = status.peek();
    status.set({ ...s, exporting: false, exportProgress: 0, exportCurrent: null });
  }
}
async function loadLogs() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_LOGS" });
    if (response == null ? void 0 : response.error) {
      logsText.set(`DeepSeek Chat Exporter v${extVersion} · 日志拉取失败: ${response.error}`);
    } else {
      const entries = (response == null ? void 0 : response.entries) || [];
      logsText.set(
        entries.length > 0 ? `${buildLogsHeader(entries.length)}
${formatAll(entries)}` : `${buildLogsHeader(0)}
暂无日志`
      );
    }
  } catch (error) {
    logsText.set(`DeepSeek Chat Exporter v${extVersion} · 日志拉取失败: ${String(error)}`);
  }
}
async function downloadLogs() {
  try {
    const text = logsText();
    if (!text || text.endsWith("暂无日志")) {
      await loadLogs();
    }
    const blob = new Blob([logsText()], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `deepseek-exporter-logs-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.log`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5e3);
  } catch (error) {
    showMessage(`日志下载失败: ${String(error)}`, true);
  }
}
async function copyLogs() {
  try {
    if (!logsText() || logsText().endsWith("暂无日志")) {
      await loadLogs();
    }
    await navigator.clipboard.writeText(logsText());
    showMessage("日志已拷贝到剪贴板", false);
  } catch (error) {
    showMessage(`日志拷贝失败: ${String(error)}`, true);
  }
}
async function clearLogs() {
  try {
    await chrome.runtime.sendMessage({ type: "CLEAR_LOGS" });
    logsText.set(`${buildLogsHeader(0)}
暂无日志`);
    showMessage("日志已清空", false);
  } catch (error) {
    showMessage(`日志清空失败: ${String(error)}`, true);
  }
}
let progressListenerAdded = false;
function ensureListeners() {
  if (progressListenerAdded) return;
  progressListenerAdded = true;
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "EXPORT_PROGRESS") {
      const payload = msg.payload;
      if (payload) {
        const s = status.peek();
        status.set({
          ...s,
          exporting: true,
          exportProgress: payload.progress,
          exportCurrent: {
            index: payload.current ?? 0,
            total: payload.total ?? 0,
            title: payload.title ?? ""
          }
        });
      }
    } else if (msg.type === "LIST_PROGRESS") {
      const payload = msg.payload;
      if (payload) {
        listLoaded.set(payload.loaded);
      }
    }
  });
}
function InfoItem(props) {
  const value = () => resolve(props.value);
  {
    const __f1 = document.createDocumentFragment();
    const __el2 = createEl("div", __f1);
    __el2.setAttribute("class", "info-item");
    const __el3 = createEl("span", __el2);
    __el3.setAttribute("class", "label");
    insert(__el3, () => resolve(props.label));
    __el2.appendChild(__el3);
    const __el4 = createEl("span", __el2);
    __el4.setAttribute("class", "value");
    insert(__el4, () => value());
    __el2.appendChild(__el4);
    __f1.appendChild(__el2);
    return __f1;
  }
}
function SessionItem(props) {
  const s = () => resolve(props.session);
  const index = () => resolve(props.index) + 1;
  const checked = () => selected().has(s().id);
  const date = () => formatSessionDate(s());
  const pinned = () => Boolean(s().pinned);
  {
    const __f5 = document.createDocumentFragment();
    const __el6 = createEl("label", __f5);
    __el6.setAttribute("class", "session-item");
    const __el7 = createEl("span", __el6);
    __el7.setAttribute("class", "session-index");
    insert(__el7, () => index());
    __el6.appendChild(__el7);
    const __el8 = createEl("input", __el6);
    __el8.setAttribute("type", "checkbox");
    effect(() => {
      __el8.checked = checked();
    });
    __el8.addEventListener("change", (e) => toggleSelect(s().id, e.target.checked));
    __el6.appendChild(__el8);
    when(__el6, () => pinned(), () => {
      const __f9 = document.createDocumentFragment();
      const __el10 = createEl("span", __f9);
      __el10.setAttribute("class", "pin-badge");
      __el10.setAttribute("title", "置顶会话");
      __el10.appendChild(document.createTextNode("\n          置顶\n        "));
      __f9.appendChild(__el10);
      return __f9;
    }, () => {
      const __f11 = document.createDocumentFragment();
      insert(__f11, () => null);
      return __f11;
    });
    const __el12 = createEl("span", __el6);
    __el12.setAttribute("class", "session-title");
    effect(() => {
      const __v = s().title;
      if (__v == null) __el12.removeAttribute("title");
      else __el12.title = __v;
    });
    insert(__el12, () => s().title || "Untitled");
    __el6.appendChild(__el12);
    when(__el6, () => date(), () => {
      const __f13 = document.createDocumentFragment();
      const __el14 = createEl("span", __f13);
      __el14.setAttribute("class", "session-date");
      insert(__el14, () => date());
      __f13.appendChild(__el14);
      return __f13;
    }, () => {
      const __f15 = document.createDocumentFragment();
      insert(__f15, () => null);
      return __f15;
    });
    __f5.appendChild(__el6);
    return __f5;
  }
}
function SessionListPanel() {
  const list = sessions;
  const ordered = computed(() => {
    const arr = [...list()];
    arr.sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)));
    return arr;
  });
  const allChecked = computed(
    () => list().length > 0 && selected().size === list().length
  );
  {
    const __f16 = document.createDocumentFragment();
    const __el17 = createEl("div", __f16);
    __el17.setAttribute("class", "panel");
    const __el18 = createEl("div", __el17);
    __el18.setAttribute("class", "panel-toolbar");
    const __el19 = createEl("label", __el18);
    __el19.setAttribute("class", "check-all");
    const __el20 = createEl("input", __el19);
    __el20.setAttribute("type", "checkbox");
    effect(() => {
      __el20.checked = allChecked();
    });
    __el20.addEventListener("change", toggleAll);
    __el19.appendChild(__el20);
    __el19.appendChild(document.createTextNode("\n          全选\n        "));
    __el18.appendChild(__el19);
    const __el21 = createEl("span", __el18);
    __el21.setAttribute("class", "muted");
    __el21.appendChild(document.createTextNode("\n          已选 "));
    insert(__el21, () => selectedCount());
    __el21.appendChild(document.createTextNode(" / "));
    insert(__el21, () => list().length);
    __el18.appendChild(__el21);
    const __el22 = createEl("button", __el18);
    __el22.setAttribute("class", "mini-btn");
    __el22.addEventListener("click", () => loadList(true));
    __el22.appendChild(document.createTextNode("\n          刷新列表\n        "));
    __el18.appendChild(__el22);
    __el17.appendChild(__el18);
    when(__el17, () => listLoading(), () => {
      const __f23 = document.createDocumentFragment();
      const __el24 = createEl("div", __f23);
      __el24.setAttribute("class", "list-loading");
      __el24.appendChild(document.createTextNode("\n          正在加载会话列表… 已加载 "));
      insert(__el24, () => listLoaded());
      __el24.appendChild(document.createTextNode(" 条\n        "));
      __f23.appendChild(__el24);
      return __f23;
    }, () => {
      const __f25 = document.createDocumentFragment();
      when(__f25, () => list().length === 0, () => {
        const __f26 = document.createDocumentFragment();
        const __el27 = createEl("div", __f26);
        __el27.setAttribute("class", "list-loading");
        __el27.appendChild(document.createTextNode("点击「刷新列表」加载会话"));
        __f26.appendChild(__el27);
        return __f26;
      }, () => {
        const __f28 = document.createDocumentFragment();
        const __el29 = createEl("div", __f28);
        __el29.setAttribute("class", "session-list");
        each(__el29, () => ordered(), (s, i) => {
          const __f30 = document.createDocumentFragment();
          const __props31 = { session: () => s, index: () => i };
          place(__f30, SessionItem(__props31));
          return __f30;
        });
        __f28.appendChild(__el29);
        return __f28;
      });
      return __f25;
    });
    __f16.appendChild(__el17);
    return __f16;
  }
}
function LogsPanel() {
  {
    const __f32 = document.createDocumentFragment();
    const __el33 = createEl("details", __f32);
    __el33.setAttribute("class", "collapsible");
    __ref(__el33, (el) => {
      const handler = () => {
        if (el.open) {
          loadLogs();
        }
      };
      el.addEventListener("toggle", handler);
      return () => el.removeEventListener("toggle", handler);
    });
    const __el34 = createEl("summary", __el33);
    __el34.appendChild(document.createTextNode("运行日志（排查问题用）"));
    __el33.appendChild(__el34);
    const __el35 = createEl("div", __el33);
    __el35.setAttribute("class", "collapsible-body");
    const __el36 = createEl("div", __el35);
    __el36.setAttribute("class", "logs-actions");
    const __el37 = createEl("button", __el36);
    __el37.setAttribute("class", "log-btn");
    __el37.addEventListener("click", loadLogs);
    __el37.appendChild(document.createTextNode("刷新"));
    __el36.appendChild(__el37);
    const __el38 = createEl("button", __el36);
    __el38.setAttribute("class", "log-btn");
    __el38.addEventListener("click", downloadLogs);
    __el38.appendChild(document.createTextNode("下载日志"));
    __el36.appendChild(__el38);
    const __el39 = createEl("button", __el36);
    __el39.setAttribute("class", "log-btn");
    __el39.addEventListener("click", copyLogs);
    __el39.appendChild(document.createTextNode("拷贝"));
    __el36.appendChild(__el39);
    const __el40 = createEl("button", __el36);
    __el40.setAttribute("class", "log-btn");
    __el40.addEventListener("click", clearLogs);
    __el40.appendChild(document.createTextNode("清空"));
    __el36.appendChild(__el40);
    __el35.appendChild(__el36);
    const __el41 = createEl("pre", __el35);
    __el41.setAttribute("class", "logs-view");
    insert(__el41, () => logsText() || "点「刷新」加载日志");
    __el35.appendChild(__el41);
    __el33.appendChild(__el35);
    __f32.appendChild(__el33);
    return __f32;
  }
}
function App() {
  const s = status;
  {
    const __f42 = document.createDocumentFragment();
    const __el43 = createEl("div", __f42);
    __el43.setAttribute("class", "popup");
    __ref(__el43, () => {
      ensureListeners();
      fetchStatus();
      loadList();
      const timer = setInterval(fetchStatus, 2e3);
      return () => {
        clearInterval(timer);
      };
    });
    const __el44 = createEl("div", __el43);
    __el44.setAttribute("class", "header");
    const __el45 = createEl("h1", __el44);
    __el45.appendChild(document.createTextNode("\n          DeepSeek Exporter\n          "));
    const __el46 = createEl("span", __el45);
    __el46.setAttribute("class", "version");
    __el46.appendChild(document.createTextNode("v"));
    insert(__el46, () => extVersion);
    __el45.appendChild(__el46);
    __el44.appendChild(__el45);
    const __el47 = createEl("div", __el44);
    effect(() => {
      __el47.className = stringify(s().connected ? "status connected" : "status");
    });
    when(__el47, () => s().connected, () => {
      const __f48 = document.createDocumentFragment();
      insert(__f48, () => "已连接");
      return __f48;
    }, () => {
      const __f49 = document.createDocumentFragment();
      insert(__f49, () => "未连接");
      return __f49;
    });
    __el44.appendChild(__el47);
    __el43.appendChild(__el44);
    when(__el43, () => s().connected, () => {
      const __f50 = document.createDocumentFragment();
      insert(__f50, () => null);
      return __f50;
    }, () => {
      const __f51 = document.createDocumentFragment();
      const __el52 = createEl("div", __f51);
      __el52.setAttribute("class", "tip");
      __el52.appendChild(document.createTextNode("\n          未连接时请刷新 DeepSeek 页面后重试\n          "));
      when(__el52, () => s().swError, () => {
        const __f53 = document.createDocumentFragment();
        const __el54 = createEl("div", __f53);
        __el54.setAttribute("class", "tip-detail");
        __el54.appendChild(document.createTextNode("原因: "));
        insert(__el54, () => s().swError);
        __f53.appendChild(__el54);
        return __f53;
      }, () => {
        const __f55 = document.createDocumentFragment();
        insert(__f55, () => null);
        return __f55;
      });
      __f51.appendChild(__el52);
      return __f51;
    });
    const __el56 = createEl("div", __el43);
    __el56.setAttribute("class", "info");
    const __props57 = { label: "删除接口:", value: () => s().deleteTemplateReady ? "已学习（可批量删除）" : "未学习（手动删除一次会话即可）" };
    place(__el56, InfoItem(__props57));
    __el43.appendChild(__el56);
    place(__el43, SessionListPanel());
    const __el59 = createEl("div", __el43);
    __el59.setAttribute("class", "actions");
    const __el60 = createEl("button", __el59);
    __el60.setAttribute("class", "btn btn-primary");
    effect(() => {
      __el60.disabled = !s().connected || !s().currentSessionId || s().exporting;
    });
    __el60.addEventListener("click", exportCurrent);
    __el60.appendChild(document.createTextNode("\n          导出当前会话\n        "));
    __el59.appendChild(__el60);
    const __el61 = createEl("button", __el59);
    __el61.setAttribute("class", "btn btn-secondary");
    effect(() => {
      __el61.disabled = s().exporting || selectedCount() === 0;
    });
    __el61.addEventListener("click", exportSelected);
    __el61.appendChild(document.createTextNode("\n          导出选中 ("));
    insert(__el61, () => selectedCount());
    __el61.appendChild(document.createTextNode(")\n        "));
    __el59.appendChild(__el61);
    const __el62 = createEl("button", __el59);
    __el62.setAttribute("class", "btn btn-danger");
    effect(() => {
      __el62.disabled = s().exporting || selectedCount() === 0 || !s().deleteTemplateReady;
    });
    __el62.addEventListener("click", deleteSelected);
    __el62.appendChild(document.createTextNode("\n          删除选中 ("));
    insert(__el62, () => selectedCount());
    __el62.appendChild(document.createTextNode(")\n        "));
    __el59.appendChild(__el62);
    __el43.appendChild(__el59);
    when(__el43, () => s().exporting, () => {
      const __f63 = document.createDocumentFragment();
      const __el64 = createEl("div", __f63);
      __el64.setAttribute("class", "progress");
      const __el65 = createEl("div", __el64);
      __el65.setAttribute("class", "progress-title");
      insert(__el65, () => progressTitle());
      __el64.appendChild(__el65);
      const __el66 = createEl("div", __el64);
      __el66.setAttribute("class", "progress-bar");
      const __el67 = createEl("div", __el66);
      __el67.setAttribute("class", "progress-fill");
      effect(() => {
        const __s = `width:${s().exportProgress}%`;
        if (typeof __s === "string") __el67.setAttribute("style", __s);
        else Object.assign(__el67.style, __s);
      });
      __el66.appendChild(__el67);
      __el64.appendChild(__el66);
      const __el68 = createEl("div", __el64);
      __el68.setAttribute("class", "progress-hint");
      __el68.appendChild(document.createTextNode("耗时操作，请保持 DeepSeek 页面开启"));
      __el64.appendChild(__el68);
      __f63.appendChild(__el64);
      return __f63;
    }, () => {
      const __f69 = document.createDocumentFragment();
      insert(__f69, () => null);
      return __f69;
    });
    when(__el43, () => message(), () => {
      const __f70 = document.createDocumentFragment();
      const __el71 = createEl("div", __f70);
      effect(() => {
        __el71.className = stringify(isError() ? "message error" : "message");
      });
      insert(__el71, () => message());
      __f70.appendChild(__el71);
      return __f70;
    }, () => {
      const __f72 = document.createDocumentFragment();
      insert(__f72, () => null);
      return __f72;
    });
    when(__el43, () => s().recentApiUrls && s().recentApiUrls.length > 0, () => {
      const __f73 = document.createDocumentFragment();
      const __el74 = createEl("details", __f73);
      __el74.setAttribute("class", "collapsible");
      const __el75 = createEl("summary", __el74);
      __el75.appendChild(document.createTextNode("API 捕获诊断 ("));
      insert(__el75, () => s().recentApiUrls.length);
      __el75.appendChild(document.createTextNode(")"));
      __el74.appendChild(__el75);
      const __el76 = createEl("div", __el74);
      __el76.setAttribute("class", "collapsible-body");
      const __el77 = createEl("ul", __el76);
      __el77.setAttribute("class", "url-list");
      each(__el77, () => s().recentApiUrls, (u) => {
        const __f78 = document.createDocumentFragment();
        const __el79 = createEl("li", __f78);
        insert(__el79, () => u);
        __f78.appendChild(__el79);
        return __f78;
      });
      __el76.appendChild(__el77);
      __el74.appendChild(__el76);
      __f73.appendChild(__el74);
      return __f73;
    }, () => {
      const __f80 = document.createDocumentFragment();
      insert(__f80, () => null);
      return __f80;
    });
    place(__el43, LogsPanel());
    when(__el43, () => confirmVisible(), () => {
      const __f82 = document.createDocumentFragment();
      const __el83 = createEl("div", __f82);
      __el83.setAttribute("class", "modal-mask");
      const __el84 = createEl("div", __el83);
      __el84.setAttribute("class", "modal");
      const __el85 = createEl("div", __el84);
      __el85.setAttribute("class", "modal-title");
      __el85.appendChild(document.createTextNode("删除确认"));
      __el84.appendChild(__el85);
      const __el86 = createEl("div", __el84);
      __el86.setAttribute("class", "modal-text");
      const __el87 = createEl("span", __el86);
      __el87.setAttribute("class", "modal-warn");
      __el87.appendChild(document.createTextNode("⚠ "));
      insert(__el87, () => confirmText());
      __el86.appendChild(__el87);
      __el84.appendChild(__el86);
      const __el88 = createEl("div", __el84);
      __el88.setAttribute("class", "modal-actions");
      const __el89 = createEl("button", __el88);
      __el89.setAttribute("class", "modal-btn");
      __el89.addEventListener("click", () => answerConfirm(false));
      __el89.appendChild(document.createTextNode("\n                取消\n              "));
      __el88.appendChild(__el89);
      const __el90 = createEl("button", __el88);
      __el90.setAttribute("class", "modal-btn danger");
      __el90.addEventListener("click", () => answerConfirm(true));
      __el90.appendChild(document.createTextNode("\n                确认删除\n              "));
      __el88.appendChild(__el90);
      __el84.appendChild(__el88);
      __el83.appendChild(__el84);
      __f82.appendChild(__el83);
      return __f82;
    }, () => {
      const __f91 = document.createDocumentFragment();
      insert(__f91, () => null);
      return __f91;
    });
    __f42.appendChild(__el43);
    return __f42;
  }
}
const logger = createLocalLogger("popup", true);
window.addEventListener("error", (e) => {
  logger.error("未捕获异常", {
    msg: e.message,
    file: (e.filename || "").split("/").pop() || "",
    line: e.lineno
  });
});
window.addEventListener("unhandledrejection", (e) => {
  const reason = e.reason instanceof Error ? `${e.reason.message}
${e.reason.stack || ""}` : String(e.reason);
  logger.error("未处理的 Promise rejection", reason.slice(0, 1e3));
});
mount("#app", App());
