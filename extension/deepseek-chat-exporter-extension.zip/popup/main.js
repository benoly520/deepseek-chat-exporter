(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
let activeEffect = null;
const effectStack = [];
let activeOwner = null;
const ownerStack = [];
const ERROR_HANDLER = Symbol("plain.errorHandler");
function untracked(fn) {
  const prev = activeEffect;
  activeEffect = null;
  try {
    return fn();
  } finally {
    activeEffect = prev;
  }
}
function cleanup(effect2) {
  effect2.deps.forEach((s) => s.subs.delete(effect2));
  effect2.deps.clear();
}
function effect(fn, owner) {
  const e = {
    deps: /* @__PURE__ */ new Set(),
    fn,
    disposed: false,
    // 创建时快照下来的 owner 链：运行期抛错时用它找最近的 ErrorBoundary
    // （不能用运行时的 ownerStack —— effect 重跑时那条栈早就空了）
    ownerChain: ownerStack.length ? ownerStack.slice() : null,
    run() {
      if (e.disposed)
        return;
      cleanup(e);
      activeEffect = e;
      effectStack.push(e);
      try {
        return fn();
      } catch (err) {
        const chain = e.ownerChain || [];
        for (let i = chain.length - 1; i >= 0; i--) {
          const h = chain[i][ERROR_HANDLER];
          if (h) {
            try {
              h(err);
            } catch (_) {
              break;
            }
            return;
          }
        }
        throw err;
      } finally {
        effectStack.pop();
        activeEffect = effectStack[effectStack.length - 1] || null;
      }
    },
    dispose() {
      if (e.disposed)
        return;
      e.disposed = true;
      cleanup(e);
      queue.delete(e);
    }
  };
  if (activeOwner)
    activeOwner.add(e.dispose);
  e.run();
  if (e.disposed)
    return e;
  return e;
}
const queue = /* @__PURE__ */ new Set();
function signal(initial) {
  const s = { value: initial, subs: /* @__PURE__ */ new Set() };
  const read = function() {
    if (activeEffect) {
      s.subs.add(activeEffect);
      activeEffect.deps.add(s);
    }
    return s.value;
  };
  read.peek = () => s.value;
  read.set = function(next) {
    const v = typeof next === "function" ? next(s.value) : next;
    if (Object.is(v, s.value))
      return v;
    s.value = v;
    const subs = Array.from(s.subs);
    subs.forEach((e) => {
      if (!e.disposed)
        e.run();
    });
    return v;
  };
  read.subs = s.subs;
  return read;
}
function computed(fn, owner) {
  const out = signal(void 0);
  effect(() => out.set(fn()));
  return out;
}
function stringify(v) {
  if (v === null || v === void 0)
    return "";
  if (typeof v === "boolean")
    return v ? "true" : "false";
  return String(v);
}
function withOwner(ownerSet, fn) {
  const prev = activeOwner;
  activeOwner = ownerSet;
  ownerStack.push(ownerSet);
  try {
    return fn();
  } finally {
    ownerStack.pop();
    activeOwner = prev;
  }
}
function getOwner() {
  return activeOwner;
}
function resolve(v) {
  return typeof v === "function" ? v() : v;
}
function rowProxy(getRow) {
  return new Proxy({}, {
    get(_t, prop) {
      const row = getRow();
      if (row === null || row === void 0)
        return void 0;
      if (prop === Symbol.toPrimitive || prop === "toString") {
        return () => String(row);
      }
      return row[prop];
    },
    set(_t, prop, value) {
      const row = getRow();
      if (row)
        row[prop] = value;
      return true;
    },
    has(_t, prop) {
      const row = getRow();
      return row ? prop in row : false;
    },
    ownKeys() {
      const row = getRow();
      return row ? Reflect.ownKeys(row) : [];
    },
    getOwnPropertyDescriptor(_t, prop) {
      const row = getRow();
      if (!row)
        return void 0;
      return { configurable: true, enumerable: true, value: row[prop] };
    }
  });
}
const SVG_NS = "http://www.w3.org/2000/svg";
const MATH_NS = "http://www.w3.org/1998/Math/MathML";
const SVG_TAGS = /* @__PURE__ */ new Set([
  "svg",
  "g",
  "path",
  "circle",
  "ellipse",
  "rect",
  "line",
  "polyline",
  "polygon",
  "text",
  "tspan",
  "defs",
  "use",
  "symbol",
  "linearGradient",
  "radialGradient",
  "stop",
  "clipPath",
  "image",
  "marker",
  "pattern",
  "mask",
  "filter",
  "feGaussianBlur",
  "feOffset",
  "feMerge",
  "feMergeNode",
  "feColorMatrix",
  "feBlend",
  "feComposite",
  "metadata",
  "switch",
  "view",
  "desc"
]);
const MATH_TAGS = /* @__PURE__ */ new Set([
  "math",
  "mi",
  "mn",
  "mo",
  "ms",
  "mtext",
  "mspace",
  "mrow",
  "mfrac",
  "msqrt",
  "mroot",
  "msup",
  "msub",
  "msubsup",
  "mover",
  "munder",
  "mmultiscripts",
  "mtable",
  "mtr",
  "mtd",
  "mlabeledtr"
]);
function nsForTag(tag) {
  if (SVG_TAGS.has(tag))
    return SVG_NS;
  if (MATH_TAGS.has(tag))
    return MATH_NS;
  return null;
}
let ctx = null;
function getHydrationCtx() {
  return ctx;
}
function suspendHydrate() {
  const saved = ctx;
  ctx = null;
  return () => {
    ctx = saved;
  };
}
function detach(node) {
  const p = node.parentNode;
  if (p)
    p.removeChild(node);
}
function peek() {
  if (!ctx)
    return null;
  return ctx.index < ctx.list.length ? ctx.list[ctx.index] : null;
}
function step() {
  if (ctx)
    ctx.index++;
}
function skipWhitespace() {
  while (ctx) {
    const n = peek();
    if (n && n.nodeType === 3 && (n.nodeValue || "").trim() === "") {
      step();
      continue;
    }
    break;
  }
}
function claimPair(openLabel, closeLabel) {
  if (!ctx)
    return null;
  skipWhitespace();
  const start = peek();
  if (!(start && start.nodeType === 8 && start.nodeValue === openLabel))
    return null;
  const content = [];
  let close = null;
  let sib = start.nextSibling;
  while (sib) {
    if (sib.nodeType === 8 && sib.nodeValue === closeLabel) {
      close = sib;
      break;
    }
    content.push(sib);
    sib = sib.nextSibling;
  }
  if (!close)
    return null;
  skipFlatTo(close);
  detach(start);
  content.forEach((c) => detach(c));
  detach(close);
  return { start, end: close, content };
}
function skipFlatTo(node) {
  if (!ctx)
    return;
  let i = ctx.index;
  while (i < ctx.list.length && ctx.list[i] !== node)
    i++;
  if (i >= ctx.list.length)
    return;
  let j = i + 1;
  while (j < ctx.list.length && isDescendant(ctx.list[j], node))
    j++;
  ctx.index = j;
}
function isDescendant(a, b) {
  let p = a.parentNode;
  while (p) {
    if (p === b)
      return true;
    p = p.parentNode;
  }
  return false;
}
const registry = /* @__PURE__ */ new Set();
let nextId = 0;
let currentModuleId = null;
function hmrRegister(record) {
  const id = record.id ?? currentModuleId ?? `__plain__${nextId++}`;
  const rec = { id, ...record };
  registry.add(rec);
  return () => registry.delete(rec);
}
let pending = [];
function __ref(el, fn) {
  if (typeof fn !== "function") {
    throw new TypeError("[plain] ref 需要一个函数：ref={(el) => { … }}；元素连入文档后会用该元素调用它一次");
  }
  const owner = getOwner();
  const entry = { el, fn, owner };
  pending.push(entry);
  if (owner && typeof owner.add === "function") {
    owner.add(() => {
      const i = pending.indexOf(entry);
      if (i >= 0)
        pending.splice(i, 1);
    });
  }
}
function flushRefs() {
  if (!pending.length)
    return;
  const run = [];
  const rest = [];
  for (const entry of pending) {
    if (entry.el && entry.el.isConnected)
      run.push(entry);
    else
      rest.push(entry);
  }
  pending = rest;
  let firstError = null;
  for (const entry of run) {
    try {
      const call = () => entry.fn(entry.el);
      const cleanup2 = entry.owner ? withOwner(entry.owner, call) : call();
      if (typeof cleanup2 === "function") {
        if (entry.owner && typeof entry.owner.add === "function") {
          entry.owner.add(cleanup2);
        }
      }
    } catch (err) {
      if (firstError === null)
        firstError = err;
    }
  }
  if (firstError !== null)
    throw firstError;
}
function createEl(tag, parent) {
  const ns = nsForTag(tag);
  if (ns)
    return document.createElementNS(ns, tag);
  const pns = parent == null ? void 0 : parent.namespaceURI;
  if (pns === SVG_NS)
    return document.createElementNS(SVG_NS, tag);
  if (pns === MATH_NS)
    return document.createElementNS(MATH_NS, tag);
  return document.createElement(tag);
}
function mount(target, node) {
  const el = document.querySelector(target);
  if (!el)
    throw new Error(`[plain] mount 找不到目标：${target}`);
  const isComp = typeof node === "function";
  const startMark = document.createComment(`${A}root]`);
  const endMark = document.createComment(`${A}/root]`);
  el.appendChild(startMark);
  el.appendChild(endMark);
  let current = [];
  let cleanups = /* @__PURE__ */ new Set();
  const render = () => {
    const n = isComp ? withOwner(cleanups, () => node()) : node;
    const nodes = toNodes(n);
    syncRange(startMark, endMark, nodes);
    current = nodes;
  };
  render();
  const unmount = () => {
    cleanups.forEach((f) => f());
    cleanups.clear();
    current.forEach((x) => x.remove && x.remove());
    startMark.remove && startMark.remove();
    endMark.remove && endMark.remove();
  };
  if (isComp) {
    const unregister = hmrRegister({
      container: el,
      comp: node,
      // 热替换时只回收旧 effect（DOM 交给 rebuild 的 syncRange 做最小重排）
      dispose: () => {
        cleanups.forEach((f) => f());
        cleanups.clear();
        cleanups = /* @__PURE__ */ new Set();
      },
      rebuild: (comp) => {
        node = comp;
        render();
      }
    });
    return () => {
      unregister();
      unmount();
    };
  }
  return unmount;
}
function toNodes(v) {
  if (v === null || v === void 0 || typeof v === "boolean")
    return [];
  if (Array.isArray(v))
    return v.flatMap(toNodes);
  if (v.nodeType === 11)
    return Array.from(v.childNodes).flatMap(toNodes);
  if (v.nodeType)
    return [v];
  return [document.createTextNode(stringify(v))];
}
function markers(parent, open, close) {
  const ctx2 = getHydrationCtx();
  if (ctx2) {
    const pair = claimPair(open, close);
    if (pair) {
      parent.appendChild(pair.start);
      for (const c of pair.content)
        parent.appendChild(c);
      parent.appendChild(pair.end);
      return [pair.start, pair.end];
    }
  }
  const doc = (parent == null ? void 0 : parent.ownerDocument) || globalThis.document;
  const start = doc.createComment(open);
  const end = doc.createComment(close);
  parent.appendChild(start);
  parent.appendChild(end);
  return [start, end];
}
const A = "plain-";
function place(parent, node) {
  if (!node)
    return node;
  const list = node.__plainSlot ? toNodes(node.fragment) : toNodes(node);
  list.forEach((n) => parent.appendChild(n));
  flushRefs();
  return node;
}
function syncRange(start, end, next) {
  const parent = start.parentNode;
  if (!parent)
    return;
  const cur = [];
  let n = start.nextSibling;
  while (n && n !== end) {
    cur.push(n);
    n = n.nextSibling;
  }
  if (getHydrationCtx()) {
    reconcileHydrate(start, end, cur, next);
    flushRefs();
    return;
  }
  cur.forEach((x) => {
    if (next.indexOf(x) === -1 && x.remove)
      x.remove();
  });
  let ref = start.nextSibling;
  for (const want of next) {
    if (ref === want) {
      ref = want.nextSibling;
      continue;
    }
    parent.insertBefore(want, ref === null ? end : ref);
  }
  flushRefs();
}
function reconcileHydrate(start, end, cur, next) {
  const parent = start.parentNode;
  if (!parent)
    return;
  const n = Math.min(cur.length, next.length);
  for (let i = 0; i < n; i++) {
    if (sameKind(cur[i], next[i])) {
      inPlaceUpdate(cur[i], next[i]);
    } else {
      parent.insertBefore(next[i], cur[i]);
      if (cur[i].remove)
        cur[i].remove();
    }
  }
  for (let i = n; i < cur.length; i++) {
    if (cur[i].remove)
      cur[i].remove();
  }
  for (let i = n; i < next.length; i++) {
    parent.insertBefore(next[i], end);
  }
}
function sameKind(a, b) {
  if (!a || !b)
    return false;
  if (a === b)
    return true;
  if (a.nodeType === 3 && b.nodeType === 3)
    return true;
  if (a.nodeType === 1 && b.nodeType === 1 && String(a.tagName).toLowerCase() === String(b.tagName).toLowerCase()) {
    return true;
  }
  return false;
}
function inPlaceUpdate(a, b) {
  if (a === b)
    return;
  if (a.nodeType === 3 && b.nodeType === 3) {
    if (a.nodeValue !== b.nodeValue)
      a.nodeValue = b.nodeValue;
    return;
  }
  if (a.nodeType === 1 && b.nodeType === 1) {
    const aAttrs = a.attributes || [];
    const bAttrs = b.attributes || [];
    const bNames = /* @__PURE__ */ new Set();
    for (const at of Array.from(bAttrs)) {
      bNames.add(at.name);
      if (a.getAttribute(at.name) !== at.value)
        a.setAttribute(at.name, at.value);
    }
    for (const at of Array.from(aAttrs)) {
      if (!bNames.has(at.name))
        a.removeAttribute(at.name);
    }
    syncChildren(a, b);
  }
}
function syncChildren(a, b) {
  const want = Array.from(b.childNodes);
  const cur = Array.from(a.childNodes);
  cur.forEach((c) => {
    if (want.indexOf(c) === -1 && c.remove)
      c.remove();
  });
  let ref = a.firstChild;
  for (const w of want) {
    if (ref === w) {
      ref = w.nextSibling;
      continue;
    }
    a.insertBefore(w, ref);
  }
}
function insert(parent, get, owner) {
  const [start, end] = markers(parent, `${A}[`, `${A}]`);
  let cleanups = null;
  effect(() => {
    if (cleanups) {
      cleanups.forEach((f) => f());
      cleanups.clear();
    }
    const set = /* @__PURE__ */ new Set();
    let v;
    let built = [];
    const resume = suspendHydrate();
    try {
      withOwner(set, () => {
        v = get();
      });
      built = toNodes(v);
    } finally {
      resume();
    }
    cleanups = set;
    syncRange(start, end, built);
  });
}
function when(parent, getCond, thenFn, elseFn, owner) {
  const [start, end] = markers(parent, `${A}?`, `${A}/?`);
  let currentKey = null;
  let cleanups = null;
  effect(() => {
    const cond = getCond();
    const key = cond ? "then" : "else";
    if (currentKey === key)
      return;
    if (cleanups) {
      cleanups.forEach((f) => f());
      cleanups.clear();
    }
    currentKey = key;
    const set = /* @__PURE__ */ new Set();
    let node = null;
    let built = [];
    const resume = suspendHydrate();
    try {
      withOwner(set, () => {
        const branch = cond ? thenFn : elseFn;
        node = branch ? branch() : null;
      });
      built = toNodes(node);
    } finally {
      resume();
    }
    cleanups = set;
    syncRange(start, end, built);
  });
}
function each(parent, getter, itemFn, keyFn, owner) {
  const [start, end] = markers(parent, `${A}#`, `${A}/#`);
  let rows = [];
  const buildRow = (item, index) => {
    const rowSignal = signal(item);
    const cleanups = /* @__PURE__ */ new Set();
    let built = null;
    let nodes = [];
    const resume = suspendHydrate();
    try {
      withOwner(cleanups, () => {
        built = itemFn(rowProxy(() => rowSignal()), index);
      });
      nodes = toNodes(built);
    } finally {
      resume();
    }
    return { key: void 0, rowSignal, cleanups, nodes };
  };
  const dropRow = (row) => {
    row.cleanups.forEach((f) => f());
    row.cleanups.clear();
    row.nodes.forEach((n) => n.remove && n.remove());
    row.nodes = [];
  };
  effect(() => {
    const arr = getter() || [];
    if (typeof keyFn !== "function") {
      while (rows.length < arr.length)
        rows.push(buildRow(arr[rows.length], rows.length));
      while (rows.length > arr.length) {
        const r = rows.pop();
        if (r)
          dropRow(r);
      }
      for (let i = 0; i < arr.length; i++)
        rows[i].rowSignal.set(arr[i]);
    }
    const flat = [];
    rows.forEach((r) => r.nodes.forEach((n) => flat.push(n)));
    syncRange(start, end, flat);
  });
}
function formatEntry(e) {
  let line = `[${e.t}] [${e.lv.toUpperCase().padEnd(5)}] [${e.sc}] ${e.msg}`;
  if (e.data !== void 0) {
    try {
      line += ` ${JSON.stringify(e.data)}`;
    } catch {
      line += " [unserializable]";
    }
  }
  return line;
}
function formatAll(entries) {
  return entries.map(formatEntry).join("\n");
}
function consolePrint(lv, scope, msg, data) {
  const prefix = `[DeepSeek Exporter][${scope}]`;
  if (lv === "error") {
    console.error(prefix, msg, data ?? "");
  } else if (lv === "warn") {
    console.warn(prefix, msg, data ?? "");
  } else {
    console.log(prefix, msg, data ?? "");
  }
}
function createLocalLogger(scope, forward = false, sink) {
  const entries = [];
  function log(lv, msg, data) {
    var _a;
    const entry = { t: (/* @__PURE__ */ new Date()).toISOString(), lv, sc: scope, msg, data };
    entries.push(entry);
    if (entries.length > 500) entries.shift();
    consolePrint(lv, scope, msg, data);
    if (forward && typeof chrome !== "undefined" && ((_a = chrome.runtime) == null ? void 0 : _a.sendMessage)) {
      try {
        const msgObj = { type: "LOG_ENTRY", payload: entry };
        const result = chrome.runtime.sendMessage(msgObj);
        if (result && typeof result.catch === "function") {
          result.catch(() => {
          });
        }
      } catch {
      }
    }
  }
  return {
    debug: (msg, data) => log("debug", msg, data),
    info: (msg, data) => log("info", msg, data),
    warn: (msg, data) => log("warn", msg, data),
    error: (msg, data) => log("error", msg, data),
    /** 本上下文的内存日志（未持久化的部分） */
    entries
  };
}
function describeError(error) {
  if (error instanceof Error) {
    return error.message || error.name || "未知错误";
  }
  return String(error);
}
const STORAGE_KEY = "ui_lang";
function detectInitialLang() {
  try {
    const ui = chrome.i18n.getUILanguage();
    return ui && ui.toLowerCase().startsWith("zh") ? "zh" : "en";
  } catch {
    return "zh";
  }
}
const lang = signal(detectInitialLang());
const zh = {
  // 标题栏与状态
  "app.connected": "已连接",
  "app.disconnected": "未连接",
  "app.disconnectedTip": "未连接时请刷新 DeepSeek 页面后重试",
  "app.reason": "原因: {msg}",
  "app.deleteApi": "删除接口:",
  "app.deleteReady": "已学习（可批量删除）",
  "app.deleteNotReady": "未学习（手动删除一次会话即可）",
  // 标签页与工具栏
  "list.tabPinned": "置顶 ({n})",
  "list.tabNormal": "非置顶 ({n})",
  "list.checkAll": "全选本页",
  "list.summary": "已选 {checked}/{total} · 共 {all}",
  "list.refresh": "刷新列表",
  "list.loading": "正在加载会话列表… 已加载 {n} 条",
  "list.loadHint": "点击「刷新列表」加载会话",
  "list.emptyPinned": "暂无置顶会话",
  "list.empty": "暂无会话",
  // 列表条目
  "item.pinBadge": "置顶",
  "item.pinTitle": "置顶会话",
  "item.untitled": "无标题",
  // 日期标签与周几
  "date.today": "今天",
  "date.yesterday": "昨天",
  "date.unknown": "日期未知",
  "date.weekdays": "周日|周一|周二|周三|周四|周五|周六",
  // 主按钮
  "action.exportCurrent": "导出当前会话",
  "action.exportSelected": "导出选中 ({n})",
  "action.deleteSelected": "删除选中 ({n})",
  // 进度
  "progress.exporting": "导出中… {p}%",
  "progress.current": "正在导出 {i}/{total}：{title}",
  "progress.hint": "耗时操作，请保持 DeepSeek 页面开启",
  // 提示消息
  "msg.loadFailed": "加载会话列表失败: {err}",
  "msg.loaded": "已加载 {n} 个会话",
  "msg.noResponse": "无响应，请刷新页面后重试",
  "msg.exportFailed": "导出失败: {err}",
  "msg.exported": "导出成功: {name}",
  "msg.exportedMulti": "导出成功: {name} ({n} 个会话)",
  "msg.selectFirstExport": "请先勾选要导出的会话",
  "msg.selectFirstDelete": "请先勾选要删除的会话",
  "msg.deleteNotLearned": "删除接口尚未学习：请先在 DeepSeek 页面上手动删除任意一个会话，扩展会自动捕获该操作",
  "msg.deleteConfirm": "即将永久删除 {n} 个会话，此操作不可恢复！确认继续？",
  "msg.deleteFailed": "删除失败: {err}",
  "msg.deleteDone": "删除完成: 成功 {ok} 个，失败 {failed} 个",
  // 日志面板
  "logs.title": "运行日志（排查问题用）",
  "logs.refresh": "刷新",
  "logs.download": "下载日志",
  "logs.copy": "拷贝",
  "logs.clear": "清空",
  "logs.hint": "点「刷新」加载日志",
  "logs.header": "DeepSeek Chat Exporter v{v} · 导出时间 {time} · 共 {n} 条日志",
  "logs.none": "暂无日志",
  "logs.fetchFailed": "DeepSeek Chat Exporter v{v} · 日志拉取失败: {err}",
  "logs.downloadFailed": "日志下载失败: {err}",
  "logs.copied": "日志已拷贝到剪贴板",
  "logs.copyFailed": "日志拷贝失败: {err}",
  "logs.cleared": "日志已清空",
  "logs.clearFailed": "日志清空失败: {err}",
  // 诊断面板
  "diag.title": "API 捕获诊断 ({n})",
  // 确认弹窗
  "modal.title": "删除确认",
  "modal.cancel": "取消",
  "modal.confirm": "确认删除",
  // 语言切换
  "lang.switchToEn": "切换到英文",
  "lang.switchToZh": "切换到中文"
};
const en = {
  // Header & status
  "app.connected": "Connected",
  "app.disconnected": "Disconnected",
  "app.disconnectedTip": "Not connected — refresh the DeepSeek page and try again",
  "app.reason": "Reason: {msg}",
  "app.deleteApi": "Delete API:",
  "app.deleteReady": "Learned (batch delete available)",
  "app.deleteNotReady": "Not learned (delete any session once on the page)",
  // Tabs & toolbar
  "list.tabPinned": "Pinned ({n})",
  "list.tabNormal": "Others ({n})",
  "list.checkAll": "Select page",
  "list.summary": "{checked}/{total} selected · {all} total",
  "list.refresh": "Refresh",
  "list.loading": "Loading sessions… {n} loaded",
  "list.loadHint": 'Click "Refresh" to load sessions',
  "list.emptyPinned": "No pinned sessions",
  "list.empty": "No sessions",
  // List item
  "item.pinBadge": "Pinned",
  "item.pinTitle": "Pinned session",
  "item.untitled": "Untitled",
  // Date labels & weekdays
  "date.today": "Today",
  "date.yesterday": "Yesterday",
  "date.unknown": "Unknown date",
  "date.weekdays": "Sun|Mon|Tue|Wed|Thu|Fri|Sat",
  // Primary actions
  "action.exportCurrent": "Export current",
  "action.exportSelected": "Export selected ({n})",
  "action.deleteSelected": "Delete selected ({n})",
  // Progress
  "progress.exporting": "Exporting… {p}%",
  "progress.current": "Exporting {i}/{total}: {title}",
  "progress.hint": "This may take a while — keep the DeepSeek tab open",
  // Messages
  "msg.loadFailed": "Failed to load sessions: {err}",
  "msg.loaded": "Loaded {n} sessions",
  "msg.noResponse": "No response — refresh the page and retry",
  "msg.exportFailed": "Export failed: {err}",
  "msg.exported": "Exported: {name}",
  "msg.exportedMulti": "Exported: {name} ({n} sessions)",
  "msg.selectFirstExport": "Select at least one session to export",
  "msg.selectFirstDelete": "Select at least one session to delete",
  "msg.deleteNotLearned": "Delete API not learned yet — delete any session manually on the DeepSeek page and the extension will capture it",
  "msg.deleteConfirm": "{n} sessions will be permanently deleted. This cannot be undone. Continue?",
  "msg.deleteFailed": "Delete failed: {err}",
  "msg.deleteDone": "Delete finished: {ok} succeeded, {failed} failed",
  // Logs panel
  "logs.title": "Runtime logs (for troubleshooting)",
  "logs.refresh": "Refresh",
  "logs.download": "Download",
  "logs.copy": "Copy",
  "logs.clear": "Clear",
  "logs.hint": 'Click "Refresh" to load logs',
  "logs.header": "DeepSeek Chat Exporter v{v} · exported at {time} · {n} entries",
  "logs.none": "No logs",
  "logs.fetchFailed": "DeepSeek Chat Exporter v{v} · failed to fetch logs: {err}",
  "logs.downloadFailed": "Failed to download logs: {err}",
  "logs.copied": "Logs copied to clipboard",
  "logs.copyFailed": "Failed to copy logs: {err}",
  "logs.cleared": "Logs cleared",
  "logs.clearFailed": "Failed to clear logs: {err}",
  // Diagnostics panel
  "diag.title": "API capture diagnostics ({n})",
  // Confirm dialog
  "modal.title": "Confirm deletion",
  "modal.cancel": "Cancel",
  "modal.confirm": "Delete",
  // Language switch
  "lang.switchToEn": "Switch to English",
  "lang.switchToZh": "Switch to Chinese"
};
const dicts = { zh, en };
function t(key, vars) {
  const template = dicts[lang()][key] ?? key;
  if (!vars) {
    return template;
  }
  return template.replace(/\{(\w+)\}/g, (raw, name) => {
    const value = vars[name];
    return value === void 0 ? raw : String(value);
  });
}
function setLang(next) {
  lang.set(next);
  try {
    chrome.storage.local.set({ [STORAGE_KEY]: next }).catch((error) => console.warn("[i18n] 语言偏好保存失败", error));
  } catch (error) {
    console.warn("[i18n] 语言偏好保存失败", error);
  }
}
async function loadLang() {
  try {
    const stored = await chrome.storage.local.get(STORAGE_KEY);
    const value = stored == null ? void 0 : stored[STORAGE_KEY];
    if (value === "zh" || value === "en") {
      lang.set(value);
    }
  } catch (error) {
    console.warn("[i18n] 语言偏好读取失败", error);
  }
}
const status = signal({
  connected: false,
  currentSessionId: null,
  capturedSessions: 0,
  capturedMessages: 0,
  exporting: false,
  exportProgress: 0
});
const message = signal(null);
const sessions = signal([]);
const selected = signal(/* @__PURE__ */ new Set());
const listLoading = signal(false);
const listLoaded = signal(0);
const activeTab = signal("normal");
const groupExpanded = signal({});
const logsText = signal("");
const extVersion = chrome.runtime.getManifest().version;
const confirmVisible = signal(false);
const confirmText = signal("");
let confirmResolve = null;
function confirmDialog(text) {
  confirmText.set(text);
  confirmVisible.set(true);
  return new Promise((resolve2) => {
    confirmResolve = resolve2;
  });
}
function answerConfirm(ok) {
  confirmVisible.set(false);
  const resolve2 = confirmResolve;
  confirmResolve = null;
  resolve2 == null ? void 0 : resolve2(ok);
}
function sessionTimeMs(s) {
  const raw = s.updated_at ?? s.created_at;
  if (raw === void 0 || raw === null || raw === "") return null;
  let ms;
  if (typeof raw === "number") {
    ms = raw > 1e12 ? raw : raw * 1e3;
  } else if (/^\d+(\.\d+)?$/.test(raw)) {
    const n = Number(raw);
    ms = n > 1e12 ? n : n * 1e3;
  } else {
    const d = new Date(raw);
    if (isNaN(d.getTime())) return null;
    ms = d.getTime();
  }
  return isNaN(new Date(ms).getTime()) ? null : ms;
}
function formatSessionDate(s) {
  const ms = sessionTimeMs(s);
  if (ms === null) return "";
  const d = new Date(ms);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
const UNKNOWN_DAY = "unknown";
function weekdayNames() {
  return t("date.weekdays").split("|");
}
function dayKeyOf(ms) {
  if (ms === null) return UNKNOWN_DAY;
  const d = new Date(ms);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function formatDayLabel(key) {
  if (key === UNKNOWN_DAY) return t("date.unknown");
  const now = Date.now();
  if (key === dayKeyOf(now)) return t("date.today");
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  if (key === dayKeyOf(yesterday.getTime())) return t("date.yesterday");
  const [y, m, d] = key.split("-").map(Number);
  const week = weekdayNames()[new Date(y, m - 1, d).getDay()] ?? "";
  const pad = (n) => String(n).padStart(2, "0");
  const md = `${pad(m)}-${pad(d)}`;
  const yearText = y === new Date(now).getFullYear() ? md : `${y}-${md}`;
  return `${yearText} ${week}`;
}
function buildLogsHeader(entryCount) {
  return t("logs.header", {
    v: extVersion,
    time: (/* @__PURE__ */ new Date()).toLocaleString(),
    n: entryCount
  });
}
const progressTitle = computed(() => {
  const cur = status().exportCurrent;
  if (cur && cur.total > 0) {
    return t("progress.current", { i: cur.index, total: cur.total, title: cur.title });
  }
  return t("progress.exporting", { p: status().exportProgress });
});
const selectedCount = computed(() => selected().size);
const pinnedList = computed(() => sessions().filter((s) => Boolean(s.pinned)));
const normalList = computed(() => sessions().filter((s) => !s.pinned));
const currentList = computed(
  () => activeTab() === "pinned" ? pinnedList() : normalList()
);
const currentCheckedCount = computed(() => {
  const sel = selected();
  return currentList().filter((s) => sel.has(s.id)).length;
});
const dateGroups = computed(() => {
  const groups = [];
  const index = /* @__PURE__ */ new Map();
  for (const s of normalList()) {
    const key = dayKeyOf(sessionTimeMs(s));
    const hit = index.get(key);
    if (hit) {
      hit.items.push(s);
    } else {
      const group = { key, label: formatDayLabel(key), start: 0, items: [s] };
      index.set(key, group);
      groups.push(group);
    }
  }
  groups.sort((a, b) => {
    if (a.key === UNKNOWN_DAY) return 1;
    if (b.key === UNKNOWN_DAY) return -1;
    return b.key.localeCompare(a.key);
  });
  let offset = 0;
  for (const g of groups) {
    g.start = offset;
    offset += g.items.length;
  }
  return groups;
});
function isGroupExpanded(key, index) {
  const explicit = groupExpanded()[key];
  return explicit === void 0 ? index === 0 : explicit;
}
function toggleGroup(key, index) {
  groupExpanded.set({ ...groupExpanded.peek(), [key]: !isGroupExpanded(key, index) });
}
async function fetchStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_STATUS" });
    if (response) {
      status.set(response);
    }
  } catch (error) {
    console.error("Failed to fetch status:", error);
  }
}
function showMessage(key, error, vars) {
  message.set(key ? { key, vars, error } : null);
}
async function loadList(force = false) {
  if (listLoading()) return;
  showMessage("", false);
  if (!force && sessions().length > 0) {
    return;
  }
  listLoading.set(true);
  listLoaded.set(0);
  try {
    const response = await chrome.runtime.sendMessage({ type: "LOAD_SESSIONS" });
    if (response == null ? void 0 : response.error) {
      showMessage("msg.loadFailed", true, { err: response.error });
      return;
    }
    const list = (response == null ? void 0 : response.sessions) || [];
    sessions.set(list);
    selected.set(new Set(list.map((s) => s.id)));
    showMessage("msg.loaded", false, { n: list.length });
  } catch (error) {
    showMessage("msg.loadFailed", true, { err: describeError(error) });
  } finally {
    listLoading.set(false);
  }
}
function toggleSelect(id, checked) {
  const next = new Set(selected.peek());
  if (checked) {
    next.add(id);
  } else {
    next.delete(id);
  }
  selected.set(next);
}
function toggleAll() {
  const tab = activeTab.peek();
  const cur = sessions.peek().filter((s) => tab === "pinned" ? Boolean(s.pinned) : !s.pinned);
  const next = new Set(selected.peek());
  const allChecked = cur.length > 0 && cur.every((s) => next.has(s.id));
  for (const s of cur) {
    if (allChecked) {
      next.delete(s.id);
    } else {
      next.add(s.id);
    }
  }
  selected.set(next);
}
async function exportCurrent() {
  showMessage("", false);
  try {
    const response = await chrome.runtime.sendMessage({ type: "EXPORT_CURRENT" });
    if (!response) {
      throw new Error(t("msg.noResponse"));
    }
    if (response.error) {
      showMessage("msg.exportFailed", true, { err: response.error });
    } else {
      showMessage("msg.exported", false, { name: response.filename });
    }
  } catch (error) {
    showMessage("msg.exportFailed", true, { err: describeError(error) });
  } finally {
    const s = status.peek();
    status.set({ ...s, exporting: false, exportProgress: 0, exportCurrent: null });
  }
}
async function exportSelected() {
  const ids = Array.from(selected.peek());
  if (ids.length === 0) {
    showMessage("msg.selectFirstExport", true);
    return;
  }
  showMessage("", false);
  try {
    const response = await chrome.runtime.sendMessage({
      type: "EXPORT_SELECTED",
      payload: { sessionIds: ids }
    });
    if (!response) {
      throw new Error(t("msg.noResponse"));
    }
    if (response.error) {
      showMessage("msg.exportFailed", true, { err: response.error });
    } else {
      showMessage("msg.exportedMulti", false, { name: response.filename, n: response.count });
    }
  } catch (error) {
    showMessage("msg.exportFailed", true, { err: describeError(error) });
  } finally {
    const s = status.peek();
    status.set({ ...s, exporting: false, exportProgress: 0, exportCurrent: null });
  }
}
async function deleteSelected() {
  const ids = Array.from(selected.peek());
  if (ids.length === 0) {
    showMessage("msg.selectFirstDelete", true);
    return;
  }
  if (!status.peek().deleteTemplateReady) {
    showMessage("msg.deleteNotLearned", true);
    return;
  }
  if (!await confirmDialog(
    t("msg.deleteConfirm", { n: ids.length })
  )) {
    return;
  }
  showMessage("", false);
  try {
    const response = await chrome.runtime.sendMessage({
      type: "DELETE_SESSIONS",
      payload: { sessionIds: ids }
    });
    if (!response) {
      throw new Error(t("msg.noResponse"));
    }
    if (response.error) {
      showMessage("msg.deleteFailed", true, { err: response.error });
    } else {
      showMessage("msg.deleteDone", response.failed > 0, {
        ok: response.ok,
        failed: response.failed
      });
      const deleted = new Set(ids);
      sessions.set(sessions.peek().filter((s) => !deleted.has(s.id)));
      selected.set(/* @__PURE__ */ new Set());
    }
  } catch (error) {
    showMessage("msg.deleteFailed", true, { err: describeError(error) });
  } finally {
    const s = status.peek();
    status.set({ ...s, exporting: false, exportProgress: 0, exportCurrent: null });
  }
}
async function loadLogs() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_LOGS" });
    if (response == null ? void 0 : response.error) {
      logsText.set(t("logs.fetchFailed", { v: extVersion, err: response.error }));
    } else {
      const entries = (response == null ? void 0 : response.entries) || [];
      logsText.set(
        entries.length > 0 ? `${buildLogsHeader(entries.length)}
${formatAll(entries)}` : `${buildLogsHeader(0)}
${t("logs.none")}`
      );
    }
  } catch (error) {
    logsText.set(t("logs.fetchFailed", { v: extVersion, err: String(error) }));
  }
}
async function downloadLogs() {
  try {
    const text = logsText();
    if (!text || text.endsWith(t("logs.none"))) {
      await loadLogs();
    }
    const blob = new Blob([logsText()], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `deepseek-exporter-logs-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.log`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5e3);
  } catch (error) {
    showMessage("logs.downloadFailed", true, { err: String(error) });
  }
}
async function copyLogs() {
  try {
    if (!logsText() || logsText().endsWith(t("logs.none"))) {
      await loadLogs();
    }
    await navigator.clipboard.writeText(logsText());
    showMessage("logs.copied", false);
  } catch (error) {
    showMessage("logs.copyFailed", true, { err: String(error) });
  }
}
async function clearLogs() {
  try {
    await chrome.runtime.sendMessage({ type: "CLEAR_LOGS" });
    logsText.set(`${buildLogsHeader(0)}
${t("logs.none")}`);
    showMessage("logs.cleared", false);
  } catch (error) {
    showMessage("logs.clearFailed", true, { err: String(error) });
  }
}
let progressListenerAdded = false;
function ensureListeners() {
  if (progressListenerAdded) return;
  progressListenerAdded = true;
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "EXPORT_PROGRESS") {
      const payload = msg.payload;
      if (payload) {
        const s = status.peek();
        status.set({
          ...s,
          exporting: true,
          exportProgress: payload.progress,
          exportCurrent: {
            index: payload.current ?? 0,
            total: payload.total ?? 0,
            title: payload.title ?? ""
          }
        });
      }
    } else if (msg.type === "LIST_PROGRESS") {
      const payload = msg.payload;
      if (payload) {
        listLoaded.set(payload.loaded);
      }
    }
  });
}
function InfoItem(props) {
  const value = () => resolve(props.value);
  {
    const __f1 = document.createDocumentFragment();
    const __el2 = createEl("div", __f1);
    __el2.setAttribute("class", "info-item");
    const __el3 = createEl("span", __el2);
    __el3.setAttribute("class", "label");
    insert(__el3, () => resolve(props.label));
    __el2.appendChild(__el3);
    const __el4 = createEl("span", __el2);
    __el4.setAttribute("class", "value");
    insert(__el4, () => value());
    __el2.appendChild(__el4);
    __f1.appendChild(__el2);
    return __f1;
  }
}
function SessionItem(props) {
  const s = () => resolve(props.session);
  const index = () => resolve(props.index) + 1;
  const checked = () => selected().has(s().id);
  const date = () => formatSessionDate(s());
  const pinned = () => Boolean(s().pinned);
  {
    const __f5 = document.createDocumentFragment();
    const __el6 = createEl("label", __f5);
    __el6.setAttribute("class", "session-item");
    const __el7 = createEl("span", __el6);
    __el7.setAttribute("class", "session-index");
    insert(__el7, () => index());
    __el6.appendChild(__el7);
    const __el8 = createEl("input", __el6);
    __el8.setAttribute("type", "checkbox");
    effect(() => {
      __el8.checked = checked();
    });
    __el8.addEventListener("change", (e) => toggleSelect(s().id, e.target.checked));
    __el6.appendChild(__el8);
    when(__el6, () => pinned(), () => {
      const __f9 = document.createDocumentFragment();
      const __el10 = createEl("span", __f9);
      __el10.setAttribute("class", "pin-badge");
      effect(() => {
        const __v = t("item.pinTitle");
        if (__v == null) __el10.removeAttribute("title");
        else __el10.title = __v;
      });
      insert(__el10, () => t("item.pinBadge"));
      __f9.appendChild(__el10);
      return __f9;
    }, () => {
      const __f11 = document.createDocumentFragment();
      insert(__f11, () => null);
      return __f11;
    });
    const __el12 = createEl("span", __el6);
    __el12.setAttribute("class", "session-title");
    effect(() => {
      const __v = s().title;
      if (__v == null) __el12.removeAttribute("title");
      else __el12.title = __v;
    });
    insert(__el12, () => s().title || t("item.untitled"));
    __el6.appendChild(__el12);
    when(__el6, () => date(), () => {
      const __f13 = document.createDocumentFragment();
      const __el14 = createEl("span", __f13);
      __el14.setAttribute("class", "session-date");
      insert(__el14, () => date());
      __f13.appendChild(__el14);
      return __f13;
    }, () => {
      const __f15 = document.createDocumentFragment();
      insert(__f15, () => null);
      return __f15;
    });
    __f5.appendChild(__el6);
    return __f5;
  }
}
function DateGroupPanel(props) {
  const g = () => resolve(props.group);
  const index = () => resolve(props.index);
  const expanded = computed(() => isGroupExpanded(g().key, index()));
  {
    const __f16 = document.createDocumentFragment();
    const __el17 = createEl("div", __f16);
    __el17.setAttribute("class", "date-group");
    const __el18 = createEl("div", __el17);
    __el18.setAttribute("class", "date-group-header");
    __el18.addEventListener("click", () => toggleGroup(g().key, index()));
    const __el19 = createEl("span", __el18);
    __el19.setAttribute("class", "date-group-arrow");
    when(__el19, () => expanded(), () => {
      const __f20 = document.createDocumentFragment();
      insert(__f20, () => "▾");
      return __f20;
    }, () => {
      const __f21 = document.createDocumentFragment();
      insert(__f21, () => "▸");
      return __f21;
    });
    __el18.appendChild(__el19);
    const __el22 = createEl("span", __el18);
    __el22.setAttribute("class", "date-group-label");
    insert(__el22, () => g().label);
    __el18.appendChild(__el22);
    const __el23 = createEl("span", __el18);
    __el23.setAttribute("class", "date-group-count");
    insert(__el23, () => g().items.length);
    __el18.appendChild(__el23);
    __el17.appendChild(__el18);
    when(__el17, () => expanded(), () => {
      const __f24 = document.createDocumentFragment();
      each(__f24, () => g().items, (s, i) => {
        const __f25 = document.createDocumentFragment();
        const __props26 = { session: () => s, index: () => g().start + i };
        place(__f25, SessionItem(__props26));
        return __f25;
      });
      return __f24;
    }, () => {
      const __f27 = document.createDocumentFragment();
      insert(__f27, () => null);
      return __f27;
    });
    __f16.appendChild(__el17);
    return __f16;
  }
}
function SessionListPanel() {
  const allChecked = computed(() => {
    const cur = currentList();
    const sel = selected();
    return cur.length > 0 && cur.every((s) => sel.has(s.id));
  });
  {
    const __f28 = document.createDocumentFragment();
    const __el29 = createEl("div", __f28);
    __el29.setAttribute("class", "panel");
    const __el30 = createEl("div", __el29);
    __el30.setAttribute("class", "list-tabs");
    const __el31 = createEl("button", __el30);
    effect(() => {
      __el31.className = stringify(activeTab() === "pinned" ? "list-tab active" : "list-tab");
    });
    __el31.addEventListener("click", () => activeTab.set("pinned"));
    insert(__el31, () => t("list.tabPinned", { n: pinnedList().length }));
    __el30.appendChild(__el31);
    const __el32 = createEl("button", __el30);
    effect(() => {
      __el32.className = stringify(activeTab() === "normal" ? "list-tab active" : "list-tab");
    });
    __el32.addEventListener("click", () => activeTab.set("normal"));
    insert(__el32, () => t("list.tabNormal", { n: normalList().length }));
    __el30.appendChild(__el32);
    __el29.appendChild(__el30);
    const __el33 = createEl("div", __el29);
    __el33.setAttribute("class", "panel-toolbar");
    const __el34 = createEl("label", __el33);
    __el34.setAttribute("class", "check-all");
    const __el35 = createEl("input", __el34);
    __el35.setAttribute("type", "checkbox");
    effect(() => {
      __el35.checked = allChecked();
    });
    __el35.addEventListener("change", toggleAll);
    __el34.appendChild(__el35);
    insert(__el34, () => t("list.checkAll"));
    __el33.appendChild(__el34);
    const __el36 = createEl("span", __el33);
    __el36.setAttribute("class", "muted");
    insert(__el36, () => t("list.summary", {
      checked: currentCheckedCount(),
      total: currentList().length,
      all: selectedCount()
    }));
    __el33.appendChild(__el36);
    const __el37 = createEl("button", __el33);
    __el37.setAttribute("class", "mini-btn");
    __el37.addEventListener("click", () => loadList(true));
    insert(__el37, () => t("list.refresh"));
    __el33.appendChild(__el37);
    __el29.appendChild(__el33);
    when(__el29, () => listLoading(), () => {
      const __f38 = document.createDocumentFragment();
      const __el39 = createEl("div", __f38);
      __el39.setAttribute("class", "list-loading");
      insert(__el39, () => t("list.loading", { n: listLoaded() }));
      __f38.appendChild(__el39);
      return __f38;
    }, () => {
      const __f40 = document.createDocumentFragment();
      when(__f40, () => sessions().length === 0, () => {
        const __f41 = document.createDocumentFragment();
        const __el42 = createEl("div", __f41);
        __el42.setAttribute("class", "list-loading");
        insert(__el42, () => t("list.loadHint"));
        __f41.appendChild(__el42);
        return __f41;
      }, () => {
        const __f43 = document.createDocumentFragment();
        const __el44 = createEl("div", __f43);
        __el44.setAttribute("class", "session-list");
        when(__el44, () => activeTab() === "pinned", () => {
          const __f45 = document.createDocumentFragment();
          when(__f45, () => pinnedList().length === 0, () => {
            const __f46 = document.createDocumentFragment();
            const __el47 = createEl("div", __f46);
            __el47.setAttribute("class", "list-empty");
            insert(__el47, () => t("list.emptyPinned"));
            __f46.appendChild(__el47);
            return __f46;
          }, () => {
            const __f48 = document.createDocumentFragment();
            each(__f48, () => pinnedList(), (s, i) => {
              const __f49 = document.createDocumentFragment();
              const __props50 = { session: () => s, index: () => i };
              place(__f49, SessionItem(__props50));
              return __f49;
            });
            return __f48;
          });
          return __f45;
        }, () => {
          const __f51 = document.createDocumentFragment();
          when(__f51, () => dateGroups().length === 0, () => {
            const __f52 = document.createDocumentFragment();
            const __el53 = createEl("div", __f52);
            __el53.setAttribute("class", "list-empty");
            insert(__el53, () => t("list.empty"));
            __f52.appendChild(__el53);
            return __f52;
          }, () => {
            const __f54 = document.createDocumentFragment();
            each(__f54, () => dateGroups(), (g, gi) => {
              const __f55 = document.createDocumentFragment();
              const __props56 = { group: () => g, index: () => gi };
              place(__f55, DateGroupPanel(__props56));
              return __f55;
            });
            return __f54;
          });
          return __f51;
        });
        __f43.appendChild(__el44);
        return __f43;
      });
      return __f40;
    });
    __f28.appendChild(__el29);
    return __f28;
  }
}
function LogsPanel() {
  {
    const __f57 = document.createDocumentFragment();
    const __el58 = createEl("details", __f57);
    __el58.setAttribute("class", "collapsible");
    __ref(__el58, (el) => {
      const handler = () => {
        if (el.open) {
          loadLogs();
        }
      };
      el.addEventListener("toggle", handler);
      return () => el.removeEventListener("toggle", handler);
    });
    const __el59 = createEl("summary", __el58);
    insert(__el59, () => t("logs.title"));
    __el58.appendChild(__el59);
    const __el60 = createEl("div", __el58);
    __el60.setAttribute("class", "collapsible-body");
    const __el61 = createEl("div", __el60);
    __el61.setAttribute("class", "logs-actions");
    const __el62 = createEl("button", __el61);
    __el62.setAttribute("class", "log-btn");
    __el62.addEventListener("click", loadLogs);
    insert(__el62, () => t("logs.refresh"));
    __el61.appendChild(__el62);
    const __el63 = createEl("button", __el61);
    __el63.setAttribute("class", "log-btn");
    __el63.addEventListener("click", downloadLogs);
    insert(__el63, () => t("logs.download"));
    __el61.appendChild(__el63);
    const __el64 = createEl("button", __el61);
    __el64.setAttribute("class", "log-btn");
    __el64.addEventListener("click", copyLogs);
    insert(__el64, () => t("logs.copy"));
    __el61.appendChild(__el64);
    const __el65 = createEl("button", __el61);
    __el65.setAttribute("class", "log-btn");
    __el65.addEventListener("click", clearLogs);
    insert(__el65, () => t("logs.clear"));
    __el61.appendChild(__el65);
    __el60.appendChild(__el61);
    const __el66 = createEl("pre", __el60);
    __el66.setAttribute("class", "logs-view");
    insert(__el66, () => logsText() || t("logs.hint"));
    __el60.appendChild(__el66);
    __el58.appendChild(__el60);
    __f57.appendChild(__el58);
    return __f57;
  }
}
function toggleLang() {
  setLang(lang.peek() === "zh" ? "en" : "zh");
}
function App() {
  const s = status;
  {
    const __f67 = document.createDocumentFragment();
    const __el68 = createEl("div", __f67);
    __el68.setAttribute("class", "popup");
    __ref(__el68, () => {
      ensureListeners();
      fetchStatus();
      loadList();
      const timer = setInterval(fetchStatus, 2e3);
      return () => {
        clearInterval(timer);
      };
    });
    const __el69 = createEl("div", __el68);
    __el69.setAttribute("class", "header");
    const __el70 = createEl("h1", __el69);
    __el70.appendChild(document.createTextNode("\n          DeepSeek Exporter\n          "));
    const __el71 = createEl("span", __el70);
    __el71.setAttribute("class", "version");
    __el71.appendChild(document.createTextNode("v"));
    insert(__el71, () => extVersion);
    __el70.appendChild(__el71);
    __el69.appendChild(__el70);
    const __el72 = createEl("div", __el69);
    __el72.setAttribute("class", "header-right");
    const __el73 = createEl("button", __el72);
    __el73.setAttribute("class", "lang-switch");
    effect(() => {
      const __v = lang() === "zh" ? t("lang.switchToEn") : t("lang.switchToZh");
      if (__v == null) __el73.removeAttribute("title");
      else __el73.title = __v;
    });
    __el73.addEventListener("click", toggleLang);
    when(__el73, () => lang() === "zh", () => {
      const __f74 = document.createDocumentFragment();
      insert(__f74, () => "EN");
      return __f74;
    }, () => {
      const __f75 = document.createDocumentFragment();
      insert(__f75, () => "ZH");
      return __f75;
    });
    __el72.appendChild(__el73);
    const __el76 = createEl("div", __el72);
    effect(() => {
      __el76.className = stringify(s().connected ? "status connected" : "status");
    });
    when(__el76, () => s().connected, () => {
      const __f77 = document.createDocumentFragment();
      insert(__f77, () => t("app.connected"));
      return __f77;
    }, () => {
      const __f78 = document.createDocumentFragment();
      insert(__f78, () => t("app.disconnected"));
      return __f78;
    });
    __el72.appendChild(__el76);
    __el69.appendChild(__el72);
    __el68.appendChild(__el69);
    when(__el68, () => s().connected, () => {
      const __f79 = document.createDocumentFragment();
      insert(__f79, () => null);
      return __f79;
    }, () => {
      const __f80 = document.createDocumentFragment();
      const __el81 = createEl("div", __f80);
      __el81.setAttribute("class", "tip");
      insert(__el81, () => t("app.disconnectedTip"));
      when(__el81, () => s().swError, () => {
        const __f82 = document.createDocumentFragment();
        const __el83 = createEl("div", __f82);
        __el83.setAttribute("class", "tip-detail");
        insert(__el83, () => t("app.reason", { msg: s().swError ?? "" }));
        __f82.appendChild(__el83);
        return __f82;
      }, () => {
        const __f84 = document.createDocumentFragment();
        insert(__f84, () => null);
        return __f84;
      });
      __f80.appendChild(__el81);
      return __f80;
    });
    const __el85 = createEl("div", __el68);
    __el85.setAttribute("class", "info");
    const __props86 = { label: () => t("app.deleteApi"), value: () => s().deleteTemplateReady ? t("app.deleteReady") : t("app.deleteNotReady") };
    place(__el85, InfoItem(__props86));
    __el68.appendChild(__el85);
    place(__el68, SessionListPanel());
    const __el88 = createEl("div", __el68);
    __el88.setAttribute("class", "actions");
    const __el89 = createEl("button", __el88);
    __el89.setAttribute("class", "btn btn-primary");
    effect(() => {
      __el89.disabled = !s().connected || !s().currentSessionId || s().exporting;
    });
    __el89.addEventListener("click", exportCurrent);
    insert(__el89, () => t("action.exportCurrent"));
    __el88.appendChild(__el89);
    const __el90 = createEl("button", __el88);
    __el90.setAttribute("class", "btn btn-secondary");
    effect(() => {
      __el90.disabled = s().exporting || selectedCount() === 0;
    });
    __el90.addEventListener("click", exportSelected);
    insert(__el90, () => t("action.exportSelected", { n: selectedCount() }));
    __el88.appendChild(__el90);
    const __el91 = createEl("button", __el88);
    __el91.setAttribute("class", "btn btn-danger");
    effect(() => {
      __el91.disabled = s().exporting || selectedCount() === 0 || !s().deleteTemplateReady;
    });
    __el91.addEventListener("click", deleteSelected);
    insert(__el91, () => t("action.deleteSelected", { n: selectedCount() }));
    __el88.appendChild(__el91);
    __el68.appendChild(__el88);
    when(__el68, () => s().exporting, () => {
      const __f92 = document.createDocumentFragment();
      const __el93 = createEl("div", __f92);
      __el93.setAttribute("class", "progress");
      const __el94 = createEl("div", __el93);
      __el94.setAttribute("class", "progress-title");
      insert(__el94, () => progressTitle());
      __el93.appendChild(__el94);
      const __el95 = createEl("div", __el93);
      __el95.setAttribute("class", "progress-bar");
      const __el96 = createEl("div", __el95);
      __el96.setAttribute("class", "progress-fill");
      effect(() => {
        const __s = `width:${s().exportProgress}%`;
        if (typeof __s === "string") __el96.setAttribute("style", __s);
        else Object.assign(__el96.style, __s);
      });
      __el95.appendChild(__el96);
      __el93.appendChild(__el95);
      const __el97 = createEl("div", __el93);
      __el97.setAttribute("class", "progress-hint");
      insert(__el97, () => t("progress.hint"));
      __el93.appendChild(__el97);
      __f92.appendChild(__el93);
      return __f92;
    }, () => {
      const __f98 = document.createDocumentFragment();
      insert(__f98, () => null);
      return __f98;
    });
    when(__el68, () => message(), () => {
      const __f99 = document.createDocumentFragment();
      const __el100 = createEl("div", __f99);
      effect(() => {
        var _a;
        __el100.className = stringify(((_a = message()) == null ? void 0 : _a.error) ? "message error" : "message");
      });
      insert(__el100, () => {
        var _a, _b;
        return t(((_a = message()) == null ? void 0 : _a.key) ?? "", (_b = message()) == null ? void 0 : _b.vars);
      });
      __f99.appendChild(__el100);
      return __f99;
    }, () => {
      const __f101 = document.createDocumentFragment();
      insert(__f101, () => null);
      return __f101;
    });
    when(__el68, () => s().recentApiUrls && s().recentApiUrls.length > 0, () => {
      const __f102 = document.createDocumentFragment();
      const __el103 = createEl("details", __f102);
      __el103.setAttribute("class", "collapsible");
      const __el104 = createEl("summary", __el103);
      insert(__el104, () => t("diag.title", { n: s().recentApiUrls.length }));
      __el103.appendChild(__el104);
      const __el105 = createEl("div", __el103);
      __el105.setAttribute("class", "collapsible-body");
      const __el106 = createEl("ul", __el105);
      __el106.setAttribute("class", "url-list");
      each(__el106, () => s().recentApiUrls, (u) => {
        const __f107 = document.createDocumentFragment();
        const __el108 = createEl("li", __f107);
        insert(__el108, () => u);
        __f107.appendChild(__el108);
        return __f107;
      });
      __el105.appendChild(__el106);
      __el103.appendChild(__el105);
      __f102.appendChild(__el103);
      return __f102;
    }, () => {
      const __f109 = document.createDocumentFragment();
      insert(__f109, () => null);
      return __f109;
    });
    place(__el68, LogsPanel());
    when(__el68, () => confirmVisible(), () => {
      const __f111 = document.createDocumentFragment();
      const __el112 = createEl("div", __f111);
      __el112.setAttribute("class", "modal-mask");
      const __el113 = createEl("div", __el112);
      __el113.setAttribute("class", "modal");
      const __el114 = createEl("div", __el113);
      __el114.setAttribute("class", "modal-title");
      insert(__el114, () => t("modal.title"));
      __el113.appendChild(__el114);
      const __el115 = createEl("div", __el113);
      __el115.setAttribute("class", "modal-text");
      const __el116 = createEl("span", __el115);
      __el116.setAttribute("class", "modal-warn");
      __el116.appendChild(document.createTextNode("⚠ "));
      insert(__el116, () => confirmText());
      __el115.appendChild(__el116);
      __el113.appendChild(__el115);
      const __el117 = createEl("div", __el113);
      __el117.setAttribute("class", "modal-actions");
      const __el118 = createEl("button", __el117);
      __el118.setAttribute("class", "modal-btn");
      __el118.addEventListener("click", () => answerConfirm(false));
      insert(__el118, () => t("modal.cancel"));
      __el117.appendChild(__el118);
      const __el119 = createEl("button", __el117);
      __el119.setAttribute("class", "modal-btn danger");
      __el119.addEventListener("click", () => answerConfirm(true));
      insert(__el119, () => t("modal.confirm"));
      __el117.appendChild(__el119);
      __el113.appendChild(__el117);
      __el112.appendChild(__el113);
      __f111.appendChild(__el112);
      return __f111;
    }, () => {
      const __f120 = document.createDocumentFragment();
      insert(__f120, () => null);
      return __f120;
    });
    __f67.appendChild(__el68);
    return __f67;
  }
}
const logger = createLocalLogger("popup", true);
window.addEventListener("error", (e) => {
  logger.error("未捕获异常", {
    msg: e.message,
    file: (e.filename || "").split("/").pop() || "",
    line: e.lineno
  });
});
window.addEventListener("unhandledrejection", (e) => {
  const reason = e.reason instanceof Error ? `${e.reason.message}
${e.reason.stack || ""}` : String(e.reason);
  logger.error("未处理的 Promise rejection", reason.slice(0, 1e3));
});
loadLang().finally(() => mount("#app", App()));
