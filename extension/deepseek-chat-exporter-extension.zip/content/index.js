"use strict";
(() => {
  // src/content/page-watcher.ts
  function extractSessionId() {
    const match = window.location.pathname.match(/\/chat\/(?:s\/)?([0-9a-fA-F][0-9a-fA-F-]*)/);
    return match ? match[1] : null;
  }
  function startPageWatcher(onChange) {
    let lastSessionId = extractSessionId();
    onChange(lastSessionId);
    window.addEventListener("popstate", () => {
      const newSessionId = extractSessionId();
      if (newSessionId !== lastSessionId) {
        lastSessionId = newSessionId;
        onChange(newSessionId);
      }
    });
    const observer = new MutationObserver(() => {
      const newSessionId = extractSessionId();
      if (newSessionId !== lastSessionId) {
        lastSessionId = newSessionId;
        onChange(newSessionId);
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      const newSessionId = extractSessionId();
      if (newSessionId !== lastSessionId) {
        lastSessionId = newSessionId;
        onChange(newSessionId);
      }
    };
    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      const newSessionId = extractSessionId();
      if (newSessionId !== lastSessionId) {
        lastSessionId = newSessionId;
        onChange(newSessionId);
      }
    };
  }

  // src/utils/logger.ts
  function consolePrint(lv, scope, msg, data) {
    const prefix = `[DeepSeek Exporter][${scope}]`;
    if (lv === "error") {
      console.error(prefix, msg, data ?? "");
    } else if (lv === "warn") {
      console.warn(prefix, msg, data ?? "");
    } else {
      console.log(prefix, msg, data ?? "");
    }
  }
  function createLocalLogger(scope, forward = false, sink) {
    const entries = [];
    function log(lv, msg, data) {
      const entry = { t: (/* @__PURE__ */ new Date()).toISOString(), lv, sc: scope, msg, data };
      entries.push(entry);
      if (entries.length > 500)
        entries.shift();
      consolePrint(lv, scope, msg, data);
      if (sink) {
        try {
          sink(entry);
        } catch {
        }
      } else if (forward && typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        try {
          const msgObj = { type: "LOG_ENTRY", payload: entry };
          const result = chrome.runtime.sendMessage(msgObj);
          if (result && typeof result.catch === "function") {
            result.catch(() => {
            });
          }
        } catch {
        }
      }
    }
    return {
      debug: (msg, data) => log("debug", msg, data),
      info: (msg, data) => log("info", msg, data),
      warn: (msg, data) => log("warn", msg, data),
      error: (msg, data) => log("error", msg, data),
      /** 本上下文的内存日志（未持久化的部分） */
      entries
    };
  }

  // src/utils/api-extract.ts
  function looksLikeMessage(o) {
    return typeof o === "object" && o !== null && "role" in o && "content" in o;
  }
  function looksLikeSession(o) {
    return typeof o === "object" && o !== null && "id" in o && "title" in o;
  }
  function findArray(root, predicate, emptyKeys, depth = 0) {
    if (depth > 5 || root == null)
      return null;
    if (Array.isArray(root)) {
      if (root.length > 0 && predicate(root[0])) {
        return root;
      }
      if (typeof root[0] === "object") {
        for (const item of root) {
          const found = findArray(item, predicate, emptyKeys, depth + 1);
          if (found)
            return found;
        }
      }
      return null;
    }
    if (typeof root === "object") {
      for (const [key, value] of Object.entries(root)) {
        if (Array.isArray(value) && value.length === 0 && emptyKeys.includes(key)) {
          return [];
        }
        const found = findArray(value, predicate, emptyKeys, depth + 1);
        if (found)
          return found;
      }
    }
    return null;
  }
  function extractMessages(data, structureOut) {
    const known = ["messages", "chat_messages", "items"];
    const paths = [
      ["data", "messages"],
      ["data", "chat_messages"],
      ["data", "biz_data", "chat_messages"],
      ["data", "biz_data", "messages"],
      ["messages"]
    ];
    for (const path of paths) {
      const arr = getAtPath(data, path);
      if (Array.isArray(arr)) {
        if (structureOut)
          structureOut.keys = `matched=data.${path.join(".")}`;
        return arr;
      }
    }
    const deep = findArray(data, looksLikeMessage, known);
    if (deep) {
      if (structureOut)
        structureOut.keys = "matched=<deep-scan: role+content array>";
      return deep;
    }
    if (structureOut) {
      structureOut.keys = describeStructure(data);
    }
    return null;
  }
  function extractSessions(data, structureOut) {
    const known = ["sessions", "items", "list"];
    const paths = [
      ["data", "sessions"],
      ["data", "items"],
      ["sessions"]
    ];
    let sessions = null;
    let matched = "";
    for (const path of paths) {
      const arr = getAtPath(data, path);
      if (Array.isArray(arr)) {
        sessions = arr;
        matched = `data.${path.join(".")}`;
        break;
      }
    }
    if (!sessions) {
      const deep = findArray(data, looksLikeSession, known);
      if (deep) {
        sessions = deep;
        matched = "<deep-scan: id+title array>";
      }
    }
    if (sessions) {
      const nextCursor = findString(data, "next_cursor") || findString(data, "cursor");
      if (structureOut)
        structureOut.keys = `matched=${matched}`;
      return { sessions, nextCursor };
    }
    if (structureOut) {
      structureOut.keys = describeStructure(data);
    }
    return null;
  }
  function getAtPath(root, path) {
    let cur = root;
    for (const key of path) {
      if (typeof cur !== "object" || cur === null || !(key in cur)) {
        return void 0;
      }
      cur = cur[key];
    }
    return cur;
  }
  function findString(root, key, depth = 0) {
    if (depth > 3 || typeof root !== "object" || root === null)
      return "";
    for (const [k, v] of Object.entries(root)) {
      if (k === key && typeof v === "string")
        return v;
      if (typeof v === "object" && v !== null) {
        const found = findString(v, key, depth + 1);
        if (found)
          return found;
      }
    }
    return "";
  }
  var STRUCTURE_PREVIEW_MAX = 2e3;
  function describeStructure(data) {
    try {
      const parts = [];
      let level = 0;
      let cur = data;
      while (typeof cur === "object" && cur !== null && !Array.isArray(cur) && level < 3) {
        const keys = Object.keys(cur);
        parts.push(`L${level}.keys=[${keys.join(",")}]`);
        const containerKey = keys.find((k) => {
          const v = cur[k];
          return typeof v === "object" && v !== null && !Array.isArray(v);
        });
        if (!containerKey)
          break;
        cur = cur[containerKey];
        level++;
      }
      const json = JSON.stringify(data);
      if (json.length <= STRUCTURE_PREVIEW_MAX) {
        parts.push(`json=${json}`);
      } else {
        parts.push(`json(${json.length}chars)=${json.slice(0, STRUCTURE_PREVIEW_MAX)}\u2026`);
      }
      return parts.join(" ");
    } catch {
      return "(unserializable)";
    }
  }

  // src/content/index.ts
  var logger = createLocalLogger("content", true);
  var currentSessionId = null;
  var capturedSessions = [];
  var capturedMessages = [];
  var hookInstalled = false;
  var authToken = "";
  var recentApiUrls = [];
  var capturedRequests = [];
  function init() {
    logger.info("Content script initializing", {
      url: location.href,
      readyState: document.readyState
    });
    setupGlobalErrorHandlers();
    injectFetchHook();
    window.addEventListener("__ds_data__", (event) => {
      const { type, data } = event.detail;
      handleCapturedData(type, data);
    });
    window.addEventListener("__ds_hook_control__", (event) => {
      if (event.detail.status === "installed") {
        hookInstalled = true;
        logger.info("Fetch hook confirmed installed");
      }
    });
    startPageWatcher((sessionId) => {
      currentSessionId = sessionId;
      logger.info("Page changed, session ID", sessionId);
      notifyBackground({
        type: "PAGE_CHANGED",
        payload: { sessionId }
      });
    });
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      handleMessage(message, sendResponse);
      return true;
    });
    logger.info("Content script initialized");
  }
  var errorDedupe = /* @__PURE__ */ new Map();
  function isOwnScript(filename) {
    return filename.includes("fetch-hook.js") || filename.includes("content/index.js");
  }
  function setupGlobalErrorHandlers() {
    window.addEventListener("error", (e) => {
      const filename = e.filename || "";
      const key = `error:${e.message}:${filename}:${e.lineno}`;
      reportDeduped(key, {
        msg: e.message,
        file: filename.split("/").pop() || "",
        line: e.lineno,
        col: e.colno,
        ours: isOwnScript(filename) || e.message.includes("DeepSeek Exporter")
      }, `\u672A\u6355\u83B7\u5F02\u5E38`);
    });
    window.addEventListener("unhandledrejection", (e) => {
      const reason = e.reason instanceof Error ? `${e.reason.message}
${e.reason.stack || ""}` : String(e.reason);
      const key = `rejection:${reason.slice(0, 300)}`;
      reportDeduped(key, { reason: reason.slice(0, 1e3) }, `\u672A\u5904\u7406\u7684 Promise rejection`);
    });
  }
  function reportDeduped(key, detail, label) {
    const now = Date.now();
    const DEDUP_WINDOW = 3e4;
    const prev = errorDedupe.get(key);
    if (prev && now - prev.last < DEDUP_WINDOW) {
      prev.count++;
      prev.last = now;
      if (prev.count % 10 === 0) {
        logger.warn(`${label}\uFF08\u5DF2\u91CD\u590D ${prev.count} \u6B21\uFF09`, detail);
      }
      return;
    }
    errorDedupe.set(key, { count: 1, last: now });
    if (errorDedupe.size > 50) {
      const oldest = errorDedupe.keys().next().value;
      if (oldest)
        errorDedupe.delete(oldest);
    }
    logger.error(label, detail);
  }
  function injectFetchHook() {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("content/fetch-hook.js");
    (document.head || document.documentElement).appendChild(script);
    script.onload = () => {
      script.remove();
      logger.debug("Fetch hook script loaded and removed from DOM");
    };
    script.onerror = () => {
      logger.error("Fetch hook script failed to load", script.src);
    };
  }
  function notifyBackground(message) {
    try {
      const result = chrome.runtime.sendMessage(message);
      if (result && typeof result.catch === "function") {
        result.catch(() => {
        });
      }
    } catch (error) {
    }
  }
  function handleCapturedData(type, data) {
    logger.debug("Captured data", type);
    try {
      if (type === "auth_token") {
        authToken = String(data);
        logger.info("Auth token captured");
      } else if (type === "api_url") {
        const url = String(data);
        logger.debug("API url", url);
        recentApiUrls = [url, ...recentApiUrls.filter((u) => u !== url)].slice(0, 20);
      } else if (type === "api_request") {
        const req = data;
        capturedRequests = [req, ...capturedRequests.filter(
          (r) => !(r.kind === req.kind && r.url === req.url && r.body === req.body)
        )].slice(0, 50);
        logger.info("API request captured", {
          kind: req.kind,
          method: req.method,
          url: req.url,
          hasBody: Boolean(req.body)
        });
        if (req.kind === "delete") {
          notifyBackground({
            type: "DELETE_REQUEST_CAPTURED",
            payload: req
          });
        }
      } else if (type === "api_parse_error") {
        const info = data;
        logger.error(`hook \u54CD\u5E94 JSON \u89E3\u6790\u5931\u8D25\uFF08${info.kind}\uFF09`, {
          status: info.status,
          error: info.error,
          bodySnippet: info.snippet
        });
      } else if (type === "session_list") {
        const structure = { keys: "" };
        const extracted = extractSessions(data, structure);
        if (!extracted) {
          logger.error("session_list \u89E3\u6790\u5931\u8D25\uFF08\u7ED3\u6784\u4E0D\u7B26\uFF09", structure.keys);
          return;
        }
        capturedSessions = mergeSessions(capturedSessions, extracted.sessions);
        logger.info("Session list captured", {
          matched: structure.keys,
          page: extracted.sessions.length,
          total: capturedSessions.length,
          nextCursor: extracted.nextCursor || "(empty)"
        });
        notifyBackground({
          type: "SESSION_LIST",
          payload: data
        });
      } else if (type === "history_messages") {
        const structure = { keys: "" };
        const messages = extractMessages(data, structure);
        if (!messages) {
          logger.error("history_messages \u89E3\u6790\u5931\u8D25\uFF08\u7ED3\u6784\u4E0D\u7B26\uFF09", structure.keys);
          return;
        }
        capturedMessages = messages;
        logger.info("History messages captured", {
          matched: structure.keys,
          count: capturedMessages.length,
          sampleRoles: messages.slice(0, 3).map((m) => m.role),
          firstKeys: messages[0] ? Object.keys(messages[0]).join(",") : "(empty)",
          // 首条消息完整 JSON（截断），用于确认真实字段结构
          firstSample: messages[0] ? JSON.stringify(messages[0]).slice(0, 1200) : "(empty)"
        });
        notifyBackground({
          type: "HISTORY_MESSAGES",
          payload: data
        });
      } else if (type === "sse_complete") {
        const sse = data;
        logger.info("SSE stream completed", {
          contentLen: sse.content?.length || 0,
          thinkingLen: sse.thinking?.length || 0,
          model: sse.model || ""
        });
        notifyBackground({
          type: "SSE_COMPLETE",
          payload: data
        });
      }
    } catch (error) {
      logger.error(`\u5904\u7406\u6355\u83B7\u6570\u636E\u65F6\u5F02\u5E38\uFF08type=${type}\uFF09`, String(error));
    }
  }
  function mergeSessions(existing, incoming) {
    const map = /* @__PURE__ */ new Map();
    for (const s of existing)
      map.set(s.id, s);
    for (const s of incoming)
      map.set(s.id, s);
    return Array.from(map.values());
  }
  async function proxyFetch(payload) {
    const method = (payload.method || "GET").toUpperCase();
    const headers = {};
    if (payload.body) {
      headers["Content-Type"] = "application/json";
    }
    if (authToken) {
      headers["Authorization"] = authToken;
    }
    logger.info("Proxy request start", {
      url: payload.url,
      method,
      body: payload.body,
      withToken: Boolean(authToken)
    });
    const response = await fetch(payload.url, {
      method,
      headers,
      // 重放页面请求：GET 不带 body，POST 透传原始 body 字符串
      body: method === "GET" || !payload.body ? void 0 : String(payload.body),
      credentials: "include"
    });
    if (!response.ok) {
      logger.error("Proxy fetch failed", {
        url: payload.url,
        status: response.status,
        statusText: response.statusText
      });
      if (response.status === 401 || response.status === 403) {
        throw new Error("\u672A\u767B\u5F55\u6216\u767B\u5F55\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u5148\u767B\u5F55 chat.deepseek.com \u540E\u91CD\u8BD5");
      }
      throw new Error(`API ${response.status}: ${response.statusText}`);
    }
    const contentType = response.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      const text = await response.text();
      logger.error("Proxy fetch \u8FD4\u56DE\u975E JSON \u54CD\u5E94", {
        url: payload.url,
        contentType,
        bodySnippet: text.slice(0, 500)
      });
      if (!authToken || /<html|login/i.test(text.slice(0, 1e3))) {
        throw new Error("\u672A\u767B\u5F55\u6216\u767B\u5F55\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u5148\u767B\u5F55 chat.deepseek.com \u540E\u91CD\u8BD5");
      }
      throw new Error(`\u54CD\u5E94\u975E JSON\uFF08content-type: ${contentType}\uFF09\uFF0CURL \u53EF\u80FD\u4E0D\u6B63\u786E`);
    }
    try {
      const json = await response.json();
      logger.debug("Proxy fetch ok", payload.url);
      return json;
    } catch (error) {
      const text = await response.text().catch(() => "(unavailable)");
      logger.error("Proxy fetch JSON \u89E3\u6790\u5931\u8D25", {
        url: payload.url,
        error: String(error),
        bodySnippet: text.slice(0, 500)
      });
      throw error;
    }
  }
  function findRequest(kind) {
    return capturedRequests.find((r) => r.kind === kind);
  }
  function downloadBlob(filename, json) {
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
    logger.info("Blob download triggered", { filename, size: json.length });
  }
  function handleMessage(message, sendResponse) {
    logger.debug("handleMessage", message.type);
    if (message.type === "GET_STATUS") {
      const status = {
        connected: hookInstalled,
        currentSessionId,
        capturedSessions: capturedSessions.length,
        capturedMessages: capturedMessages.length,
        exporting: false,
        exportProgress: 0,
        recentApiUrls
      };
      sendResponse(status);
    } else if (message.type === "EXPORT_CURRENT") {
      if (!currentSessionId) {
        logger.warn("EXPORT_CURRENT requested but no session id");
        sendResponse({ error: "\u672A\u627E\u5230\u5F53\u524D\u4F1A\u8BDD\uFF0C\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u5BF9\u8BDD" });
        return;
      }
      logger.info("EXPORT_CURRENT requested", {
        sessionId: currentSessionId,
        capturedCount: capturedMessages.length
      });
      sendResponse({
        sessionId: currentSessionId,
        messages: capturedMessages,
        historyRequest: findRequest("history"),
        fetchPageRequest: findRequest("fetchPage")
      });
    } else if (message.type === "EXPORT_ALL") {
      logger.info("EXPORT_ALL requested", {
        capturedSessions: capturedSessions.length,
        fetchPageRequests: capturedRequests.filter((r) => r.kind === "fetchPage").length
      });
      sendResponse({
        sessions: capturedSessions,
        fetchPageRequest: findRequest("fetchPage"),
        historyRequest: findRequest("history")
      });
    } else if (message.type === "FETCH_PROXY") {
      proxyFetch(message.payload).then((data) => sendResponse({ data })).catch((error) => sendResponse({ error: String(error) }));
    } else if (message.type === "DOWNLOAD_BLOB") {
      const { filename, json } = message.payload;
      try {
        downloadBlob(filename, json);
        sendResponse({ success: true });
      } catch (error) {
        logger.error("Blob download failed", String(error));
        sendResponse({ error: String(error) });
      }
    }
  }
  init();
})();
