"use strict";
(() => {
  // src/content/fetch-hook.ts
  (function() {
    "use strict";
    const originalFetch = window.fetch;
    const XHR = XMLHttpRequest.prototype;
    const originalXhrOpen = XHR.open;
    const originalXhrSend = XHR.send;
    const originalXhrSetHeader = XHR.setRequestHeader;
    let lastAuthToken = "";
    function isSessionListApi(url) {
      return url.includes("chat_session/fetch_page");
    }
    function isHistoryApi(url) {
      return url.includes("history_messages");
    }
    function noteApiUrl(url) {
      if (!url.includes("/api/"))
        return;
      dispatchDataEvent("api_url", url);
    }
    function noteApiRequest(url, method, body) {
      if (!url.includes("/api/"))
        return;
      let kind = "other";
      if (isSessionListApi(url)) {
        kind = "fetchPage";
      } else if (isHistoryApi(url)) {
        kind = "history";
      } else if (/chat_session\/delete|\/delete/i.test(url)) {
        kind = "delete";
      } else {
        return;
      }
      dispatchDataEvent("api_request", {
        kind,
        url,
        method: method.toUpperCase(),
        body: typeof body === "string" && body ? body : void 0
      });
    }
    window.fetch = async function(...args) {
      const [input, init] = args;
      const url = typeof input === "string" ? input : input instanceof Request ? input.url : String(input);
      const method = (init?.method || (input instanceof Request ? input.method : "GET")).toUpperCase();
      const reqBody = typeof init?.body === "string" ? init.body : void 0;
      noteApiUrl(url);
      noteApiRequest(url, method, reqBody);
      const authHeader = readHeader(input, init, "authorization");
      if (authHeader && authHeader !== lastAuthToken) {
        lastAuthToken = authHeader;
        dispatchDataEvent("auth_token", authHeader);
      }
      const acceptHeader = readHeader(input, init, "accept");
      const shouldIntercept = isSessionListApi(url) || isHistoryApi(url) || acceptHeader.includes("text/event-stream");
      if (!shouldIntercept) {
        return originalFetch.apply(this, args);
      }
      try {
        const response = await originalFetch.apply(this, args);
        const clonedResponse = response.clone();
        if (isSessionListApi(url)) {
          handleSessionListResponse(clonedResponse);
        } else if (isHistoryApi(url)) {
          handleHistoryMessagesResponse(clonedResponse);
        } else if (acceptHeader.includes("text/event-stream")) {
          handleSSEResponse(clonedResponse);
        }
        return response;
      } catch (error) {
        console.error("[DeepSeek Exporter] Fetch interception error:", error);
        return originalFetch.apply(this, args);
      }
    };
    function readHeader(input, init, name) {
      let headers;
      if (input instanceof Request) {
        headers = input.headers;
      }
      if (init?.headers) {
        headers = normalizeHeaders(init.headers);
      }
      return headers?.get(name) || "";
    }
    function normalizeHeaders(value) {
      if (value instanceof Headers)
        return value;
      if (Array.isArray(value))
        return new Headers(value);
      if (typeof value === "object")
        return new Headers(value);
      return void 0;
    }
    XHR.open = function(...args) {
      const url = args[1];
      this.__dsUrl = typeof url === "string" ? url : String(url);
      this.__dsMethod = String(args[0] || "GET");
      return originalXhrOpen.apply(this, args);
    };
    XHR.setRequestHeader = function(name, value) {
      if (String(name).toLowerCase() === "authorization" && value && value !== lastAuthToken) {
        lastAuthToken = value;
        dispatchDataEvent("auth_token", value);
      }
      return originalXhrSetHeader.call(this, name, value);
    };
    XHR.send = function(...sendArgs) {
      const url = this.__dsUrl || "";
      const method = this.__dsMethod || "GET";
      const rawBody = sendArgs[0];
      const body = typeof rawBody === "string" ? rawBody : void 0;
      noteApiUrl(url);
      noteApiRequest(url, method, body);
      if (isSessionListApi(url) || isHistoryApi(url)) {
        this.addEventListener("load", () => {
          try {
            const finalUrl = this.responseURL || url;
            const contentType = this.getResponseHeader("content-type") || "";
            if (!contentType.includes("application/json"))
              return;
            const data = JSON.parse(this.responseText);
            if (isSessionListApi(finalUrl)) {
              dispatchDataEvent("session_list", data);
            } else if (isHistoryApi(finalUrl)) {
              dispatchDataEvent("history_messages", data);
            }
          } catch (error) {
            console.error("[DeepSeek Exporter] Failed to parse XHR response:", error);
          }
        });
      }
      return originalXhrSend.apply(this, sendArgs);
    };
    async function handleSessionListResponse(response) {
      try {
        const data = await response.json();
        dispatchDataEvent("session_list", data);
      } catch (error) {
        await reportParseError("session_list", response, error);
      }
    }
    async function handleHistoryMessagesResponse(response) {
      try {
        const data = await response.json();
        dispatchDataEvent("history_messages", data);
      } catch (error) {
        await reportParseError("history_messages", response, error);
      }
    }
    async function reportParseError(kind, response, error) {
      console.error("[DeepSeek Exporter] Failed to parse", kind, error);
      let snippet = "";
      try {
        snippet = (await response.text()).slice(0, 800);
      } catch {
        snippet = "(body unavailable)";
      }
      dispatchDataEvent("api_parse_error", {
        kind,
        status: response.status,
        error: String(error),
        snippet
      });
    }
    async function handleSSEResponse(response) {
      try {
        if (!response.body) {
          console.warn("[DeepSeek Exporter] SSE response has no body");
          return;
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let assembledContent = "";
        let assembledThinking = "";
        let model = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done)
            break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith(":"))
              continue;
            if (trimmed.startsWith("data: ")) {
              const data = trimmed.slice(6);
              if (data === "[DONE]") {
                dispatchDataEvent("sse_complete", {
                  content: assembledContent,
                  thinking: assembledThinking,
                  model
                });
                return;
              }
              try {
                const parsed = JSON.parse(data);
                if (parsed.choices?.[0]?.delta) {
                  const delta = parsed.choices[0].delta;
                  if (delta.content) {
                    assembledContent += delta.content;
                  }
                  if (delta.thinking) {
                    assembledThinking += delta.thinking;
                  }
                }
                if (parsed.model) {
                  model = parsed.model;
                }
              } catch (e) {
              }
            }
          }
        }
        if (assembledContent || assembledThinking) {
          dispatchDataEvent("sse_complete", {
            content: assembledContent,
            thinking: assembledThinking,
            model
          });
        }
      } catch (error) {
        console.error("[DeepSeek Exporter] Failed to process SSE stream:", error);
      }
    }
    function dispatchDataEvent(type, data) {
      window.dispatchEvent(
        new CustomEvent("__ds_data__", {
          detail: { type, data }
        })
      );
    }
    window.dispatchEvent(new CustomEvent("__ds_hook_control__", {
      detail: { status: "installed" }
    }));
    console.log("[DeepSeek Exporter] Fetch hook installed (fetch + XHR)");
  })();
})();
