// src/utils/api-extract.ts
function looksLikeMessage(o) {
  return typeof o === "object" && o !== null && "role" in o && "content" in o;
}
function looksLikeSession(o) {
  return typeof o === "object" && o !== null && "id" in o && "title" in o;
}
function findArray(root, predicate, emptyKeys, depth = 0) {
  if (depth > 5 || root == null)
    return null;
  if (Array.isArray(root)) {
    if (root.length > 0 && predicate(root[0])) {
      return root;
    }
    if (typeof root[0] === "object") {
      for (const item of root) {
        const found = findArray(item, predicate, emptyKeys, depth + 1);
        if (found)
          return found;
      }
    }
    return null;
  }
  if (typeof root === "object") {
    for (const [key, value] of Object.entries(root)) {
      if (Array.isArray(value) && value.length === 0 && emptyKeys.includes(key)) {
        return [];
      }
      const found = findArray(value, predicate, emptyKeys, depth + 1);
      if (found)
        return found;
    }
  }
  return null;
}
function extractMessages(data, structureOut) {
  const known = ["messages", "chat_messages", "items"];
  const paths = [
    ["data", "messages"],
    ["data", "chat_messages"],
    ["data", "biz_data", "chat_messages"],
    ["data", "biz_data", "messages"],
    ["messages"]
  ];
  for (const path of paths) {
    const arr = getAtPath(data, path);
    if (Array.isArray(arr)) {
      if (structureOut)
        structureOut.keys = `matched=data.${path.join(".")}`;
      return arr;
    }
  }
  const deep = findArray(data, looksLikeMessage, known);
  if (deep) {
    if (structureOut)
      structureOut.keys = "matched=<deep-scan: role+content array>";
    return deep;
  }
  if (structureOut) {
    structureOut.keys = describeStructure(data);
  }
  return null;
}
function extractSessions(data, structureOut) {
  const known = ["sessions", "items", "list"];
  const paths = [
    ["data", "sessions"],
    ["data", "items"],
    ["sessions"]
  ];
  let sessions = null;
  let matched = "";
  for (const path of paths) {
    const arr = getAtPath(data, path);
    if (Array.isArray(arr)) {
      sessions = arr;
      matched = `data.${path.join(".")}`;
      break;
    }
  }
  if (!sessions) {
    const deep = findArray(data, looksLikeSession, known);
    if (deep) {
      sessions = deep;
      matched = "<deep-scan: id+title array>";
    }
  }
  if (sessions) {
    const nextCursor = findString(data, "next_cursor") || findString(data, "cursor");
    if (structureOut)
      structureOut.keys = `matched=${matched}`;
    return { sessions, nextCursor };
  }
  if (structureOut) {
    structureOut.keys = describeStructure(data);
  }
  return null;
}
function getAtPath(root, path) {
  let cur = root;
  for (const key of path) {
    if (typeof cur !== "object" || cur === null || !(key in cur)) {
      return void 0;
    }
    cur = cur[key];
  }
  return cur;
}
function findString(root, key, depth = 0) {
  if (depth > 3 || typeof root !== "object" || root === null)
    return "";
  for (const [k, v] of Object.entries(root)) {
    if (k === key && typeof v === "string")
      return v;
    if (typeof v === "object" && v !== null) {
      const found = findString(v, key, depth + 1);
      if (found)
        return found;
    }
  }
  return "";
}
var STRUCTURE_PREVIEW_MAX = 2e3;
function describeStructure(data) {
  try {
    const parts = [];
    let level = 0;
    let cur = data;
    while (typeof cur === "object" && cur !== null && !Array.isArray(cur) && level < 3) {
      const keys = Object.keys(cur);
      parts.push(`L${level}.keys=[${keys.join(",")}]`);
      const containerKey = keys.find((k) => {
        const v = cur[k];
        return typeof v === "object" && v !== null && !Array.isArray(v);
      });
      if (!containerKey)
        break;
      cur = cur[containerKey];
      level++;
    }
    const json = JSON.stringify(data);
    if (json.length <= STRUCTURE_PREVIEW_MAX) {
      parts.push(`json=${json}`);
    } else {
      parts.push(`json(${json.length}chars)=${json.slice(0, STRUCTURE_PREVIEW_MAX)}\u2026`);
    }
    return parts.join(" ");
  } catch {
    return "(unserializable)";
  }
}
function extractMessageBody(msg, sampleOut) {
  const found = { content: "" };
  if (typeof msg !== "object" || msg === null) {
    return found;
  }
  const topLevel = msg;
  const textKeys = ["content", "text", "message_content", "content_text"];
  for (const key of textKeys) {
    const v = topLevel[key];
    if (typeof v === "string" && v.trim()) {
      found.content = v;
      break;
    }
  }
  if (!found.content) {
    const fragKeys = [
      "fragment_content",
      "content_chunks",
      "fragments",
      "segments",
      "content_segments"
    ];
    for (const key of fragKeys) {
      const arr = topLevel[key];
      if (Array.isArray(arr)) {
        const joined = joinFragmentTexts(arr);
        if (joined) {
          found.content = joined;
          break;
        }
      }
    }
  }
  const thinkingKeys = ["thinking", "reasoning", "thinking_content", "reasoning_content"];
  for (const key of thinkingKeys) {
    const v = topLevel[key];
    if (typeof v === "string" && v.trim()) {
      found.thinking = v;
      break;
    }
  }
  if (!found.content) {
    const deep = deepFindContent(msg, 0);
    if (deep) {
      found.content = deep;
    }
  }
  if (!found.content && sampleOut) {
    sampleOut.sample = describeStructure(msg);
  }
  return found;
}
function joinFragmentTexts(arr) {
  const parts = [];
  for (const item of arr) {
    if (typeof item === "string") {
      parts.push(item);
    } else if (typeof item === "object" && item !== null) {
      const t = item;
      const text = t.text ?? t.content ?? t.value;
      if (typeof text === "string") {
        parts.push(text);
      }
    }
  }
  return parts.join("");
}
function deepFindContent(root, depth) {
  if (depth > 3 || typeof root !== "object" || root === null)
    return "";
  let bestText = "";
  for (const [key, value] of Object.entries(root)) {
    if (Array.isArray(value) && value.length > 0) {
      const joined = joinFragmentTexts(value);
      if (joined && joined.length > bestText.length) {
        bestText = joined;
      }
    } else if (typeof value === "string" && /content|text/i.test(key) && !/query|id|type|status/i.test(key) && value.length > bestText.length) {
      bestText = value;
    } else if (typeof value === "object" && value !== null) {
      const nested = deepFindContent(value, depth + 1);
      if (nested.length > bestText.length) {
        bestText = nested;
      }
    }
  }
  return bestText;
}
function normalizeRole(role) {
  const r = String(role || "").toLowerCase();
  if (r === "assistant" || r === "user" || r === "system") {
    return r;
  }
  return r === "bot" ? "assistant" : r;
}
function toIsoTimestamp(v) {
  if (typeof v === "number" && isFinite(v)) {
    const ms = v > 1e12 ? v : v * 1e3;
    const d = new Date(ms);
    return isNaN(d.getTime()) ? "" : d.toISOString();
  }
  if (typeof v === "string" && v) {
    if (/^\d+(\.\d+)?$/.test(v)) {
      return toIsoTimestamp(Number(v));
    }
    const d = new Date(v);
    return isNaN(d.getTime()) ? "" : d.toISOString();
  }
  return "";
}

// src/utils/json-builder.ts
function buildExportJSON(conversations, user) {
  return {
    export_meta: {
      exporter: "deepseek-chat-exporter",
      version: "1.0.0",
      exported_at: (/* @__PURE__ */ new Date()).toISOString(),
      source: "chat.deepseek.com"
    },
    user,
    conversations
  };
}
function convertMessages(rawMessages, onSample) {
  return rawMessages.map((msg) => {
    const sampleOut = { sample: "" };
    const body = extractMessageBody(msg, sampleOut);
    if (!body.content && sampleOut.sample && onSample) {
      onSample(msg, sampleOut.sample);
    }
    return {
      role: normalizeRole(msg.role),
      content: body.content,
      thinking: body.thinking ?? (typeof msg.thinking === "string" ? msg.thinking : void 0),
      // 缺失时间戳时保留空串，不用导出时刻的时间伪造，避免数据失真
      created_at: toIsoTimestamp(msg.created_at),
      id: typeof msg.id === "string" ? msg.id : void 0,
      attachments: Array.isArray(msg.attachments) ? msg.attachments.map((att) => ({
        type: String(att?.type ?? ""),
        url: String(att?.url ?? ""),
        name: typeof att?.name === "string" ? att.name : void 0
      })) : void 0
    };
  });
}
function buildConversation(session, rawMessages, onSample) {
  return {
    id: session.id,
    title: session.title || "Untitled",
    model: session.model || "deepseek-chat",
    created_at: toIsoTimestamp(session.created_at),
    updated_at: toIsoTimestamp(session.updated_at),
    messages: convertMessages(rawMessages, onSample)
  };
}

// src/utils/downloader.ts
var DATA_URL_MAX = 15e5;
function utf8ToBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = "";
  const chunkSize = 32768;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(bin);
}
function chromeDownload(url, filename) {
  return new Promise((resolve, reject) => {
    chrome.downloads.download({ url, filename, saveAs: true }, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
      } else {
        resolve();
      }
    });
  });
}
async function triggerDownload(data, filename, tabId) {
  const json = JSON.stringify(data, null, 2);
  const sizeHint = `${json.length} chars`;
  if (json.length <= DATA_URL_MAX) {
    try {
      const dataUrl = `data:application/json;base64,${utf8ToBase64(json)}`;
      await chromeDownload(dataUrl, filename);
      console.info("[DeepSeek Exporter][sw] Download via data URL:", filename, sizeHint);
      return;
    } catch (error) {
      console.warn("[DeepSeek Exporter][sw] data URL download failed, fallback to content:", error);
    }
  }
  if (tabId) {
    await chrome.tabs.sendMessage(tabId, {
      type: "DOWNLOAD_BLOB",
      payload: { filename, json }
    });
    console.info("[DeepSeek Exporter][sw] Download via content blob:", filename, sizeHint);
    return;
  }
  throw new Error("\u65E0\u6CD5\u89E6\u53D1\u4E0B\u8F7D\uFF1Adata URL \u65B9\u5F0F\u5931\u8D25\u4E14\u6CA1\u6709\u53EF\u7528\u7684 DeepSeek \u6807\u7B7E\u9875");
}
function generateFilename(prefix = "deepseek-export") {
  const now = /* @__PURE__ */ new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const timestamp = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;
  return `${prefix}-${timestamp}.json`;
}

// src/utils/logger.ts
var MAX_PERSISTED_ENTRIES = 1e3;
var LOG_STORAGE_KEY = "ds_exporter_logs";
function formatEntry(e) {
  let line = `[${e.t}] [${e.lv.toUpperCase().padEnd(5)}] [${e.sc}] ${e.msg}`;
  if (e.data !== void 0) {
    try {
      line += ` ${JSON.stringify(e.data)}`;
    } catch {
      line += " [unserializable]";
    }
  }
  return line;
}
function formatAll(entries) {
  return entries.map(formatEntry).join("\n");
}
function consolePrint(lv, scope, msg, data) {
  const prefix = `[DeepSeek Exporter][${scope}]`;
  if (lv === "error") {
    console.error(prefix, msg, data ?? "");
  } else if (lv === "warn") {
    console.warn(prefix, msg, data ?? "");
  } else {
    console.log(prefix, msg, data ?? "");
  }
}
function createLocalLogger(scope, forward = false, sink) {
  const entries = [];
  function log(lv, msg, data) {
    const entry = { t: (/* @__PURE__ */ new Date()).toISOString(), lv, sc: scope, msg, data };
    entries.push(entry);
    if (entries.length > 500)
      entries.shift();
    consolePrint(lv, scope, msg, data);
    if (sink) {
      try {
        sink(entry);
      } catch {
      }
    } else if (forward && typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
      try {
        const msgObj = { type: "LOG_ENTRY", payload: entry };
        const result = chrome.runtime.sendMessage(msgObj);
        if (result && typeof result.catch === "function") {
          result.catch(() => {
          });
        }
      } catch {
      }
    }
  }
  return {
    debug: (msg, data) => log("debug", msg, data),
    info: (msg, data) => log("info", msg, data),
    warn: (msg, data) => log("warn", msg, data),
    error: (msg, data) => log("error", msg, data),
    /** 本上下文的内存日志（未持久化的部分） */
    entries
  };
}

// src/utils/log-store.ts
var LogStore = class {
  entries = [];
  loaded = false;
  loadPromise = null;
  persistTimer = null;
  /**
   * 从 chrome.storage.local 恢复历史日志（幂等）。
   */
  init() {
    if (this.loadPromise)
      return this.loadPromise;
    this.loadPromise = (async () => {
      try {
        const result = await chrome.storage.local.get(LOG_STORAGE_KEY);
        const stored = result[LOG_STORAGE_KEY];
        if (Array.isArray(stored) && stored.length > 0) {
          this.entries = stored;
        }
      } catch (error) {
        console.error("[DeepSeek Exporter][sw] Failed to load logs:", error);
      } finally {
        this.loaded = true;
      }
    })();
    return this.loadPromise;
  }
  /**
   * 追加日志（自动去抖持久化）。
   */
  add(entry) {
    this.entries.push(entry);
    if (this.entries.length > MAX_PERSISTED_ENTRIES) {
      this.entries.splice(0, this.entries.length - MAX_PERSISTED_ENTRIES);
    }
    this.schedulePersist();
  }
  /**
   * 获取全部日志（确保已完成历史恢复）。
   */
  async getAll() {
    if (!this.loaded) {
      await this.init();
    }
    return [...this.entries];
  }
  /**
   * 导出为文本。
   */
  async getText() {
    const entries = await this.getAll();
    return formatAll(entries);
  }
  /**
   * 清空日志（内存 + 存储）。
   */
  async clear() {
    this.entries = [];
    try {
      await chrome.storage.local.remove(LOG_STORAGE_KEY);
    } catch (error) {
      console.error("[DeepSeek Exporter][sw] Failed to clear logs:", error);
    }
  }
  /**
   * 节流持久化：500ms 内的连续日志合并写一次。
   */
  schedulePersist() {
    if (this.persistTimer)
      return;
    this.persistTimer = setTimeout(() => {
      this.persistTimer = null;
      chrome.storage.local.set({ [LOG_STORAGE_KEY]: this.entries.slice(-MAX_PERSISTED_ENTRIES) }).catch((error) => console.error("[DeepSeek Exporter][sw] Failed to persist logs:", error));
    }, 500);
  }
};

// src/utils/error.ts
function describeError(error) {
  if (error instanceof Error) {
    return error.message || error.name || "\u672A\u77E5\u9519\u8BEF";
  }
  return String(error);
}

// src/background/service-worker.ts
var logger = createLocalLogger("sw", false, (entry) => logStore.add(entry));
var logStore = new LogStore();
logStore.init();
logger.info("Service worker started", { version: chrome.runtime.getManifest().version });
var exportInProgress = false;
var exportProgress = 0;
var exportCurrent = null;
var sessionCache = [];
var sessionCacheTime = 0;
var SESSION_CACHE_TTL = 6e4;
var DELETE_TEMPLATE_KEY = "ds_exporter_delete_template";
var deleteTemplate = null;
var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
chrome.storage.local.get(DELETE_TEMPLATE_KEY).then((result) => {
  const stored = result[DELETE_TEMPLATE_KEY];
  if (stored?.url) {
    deleteTemplate = stored;
    logger.info("Delete template restored", stored.url);
  }
}).catch(() => {
});
var API_BASE = "https://chat.deepseek.com";
var FETCH_PAGE_PATH = "/api/v0/chat_session/fetch_page";
var SESSION_PAGE_SIZE = 50;
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type !== "LOG_ENTRY") {
    logger.debug("Message received", message.type);
  }
  if (message.type === "LOG_ENTRY") {
    logStore.add(message.payload);
    sendResponse({ success: true });
  } else if (message.type === "GET_LOGS") {
    logStore.getAll().then((entries) => {
      sendResponse({ entries });
    }).catch((error) => sendResponse({ error: describeError(error) }));
    return true;
  } else if (message.type === "CLEAR_LOGS") {
    logStore.clear().then(() => sendResponse({ success: true })).catch((error) => sendResponse({ error: describeError(error) }));
    return true;
  } else if (message.type === "GET_STATUS") {
    getStatus(sendResponse);
    return true;
  } else if (message.type === "EXPORT_CURRENT") {
    exportCurrentConversation(sendResponse);
    return true;
  } else if (message.type === "LOAD_SESSIONS") {
    loadAllSessions(sendResponse);
    return true;
  } else if (message.type === "EXPORT_SELECTED") {
    exportSelectedConversations(
      message.payload.sessionIds,
      sendResponse
    );
    return true;
  } else if (message.type === "DELETE_SESSIONS") {
    deleteSessions(
      message.payload.sessionIds,
      sendResponse
    );
    return true;
  } else if (message.type === "DELETE_REQUEST_CAPTURED") {
    const req = message.payload;
    deleteTemplate = req;
    chrome.storage.local.set({ [DELETE_TEMPLATE_KEY]: req }).catch((error) => logger.error("Failed to persist delete template", describeError(error)));
    logger.info("Delete template learned", { url: req.url, method: req.method });
    sendResponse({ success: true });
  } else if (message.type === "SESSION_LIST" || message.type === "HISTORY_MESSAGES" || message.type === "SSE_COMPLETE" || message.type === "PAGE_CHANGED" || message.type === "AUTH_TOKEN") {
    sendResponse({ success: true });
  }
  return true;
});
async function getActiveDeepSeekTabId() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs.find((t) => t.url?.includes("chat.deepseek.com"));
    return tab?.id ?? null;
  } catch (error) {
    logger.error("Failed to query tabs", describeError(error));
    return null;
  }
}
async function getStatus(sendResponse) {
  const idleStatus = {
    connected: false,
    currentSessionId: null,
    capturedSessions: 0,
    capturedMessages: 0,
    exporting: exportInProgress,
    exportProgress,
    exportCurrent
  };
  const tabId = await getActiveDeepSeekTabId();
  if (!tabId) {
    logger.debug("GET_STATUS: no active DeepSeek tab");
    sendResponse({ ...idleStatus, swError: "\u672A\u627E\u5230\u6D3B\u8DC3\u7684 DeepSeek \u6807\u7B7E\u9875" });
    return;
  }
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: "GET_STATUS" });
    if (response) {
      sendResponse({
        ...response,
        exporting: exportInProgress,
        exportProgress,
        exportCurrent,
        deleteTemplateReady: Boolean(deleteTemplate),
        sessionCacheCount: sessionCache.length
      });
    } else {
      sendResponse({ ...idleStatus, swError: "content script \u7A7A\u54CD\u5E94" });
    }
  } catch (error) {
    logger.warn("GET_STATUS: content script unreachable", describeError(error));
    sendResponse({
      ...idleStatus,
      swError: `content script \u4E0D\u53EF\u8FBE: ${describeError(error)}`,
      deleteTemplateReady: Boolean(deleteTemplate),
      sessionCacheCount: sessionCache.length
    });
  }
}
function broadcastListProgress(loaded) {
  try {
    const result = chrome.runtime.sendMessage({
      type: "LIST_PROGRESS",
      payload: { loaded }
    });
    if (result && typeof result.catch === "function") {
      result.catch(() => {
      });
    }
  } catch {
  }
}
async function loadAllSessions(sendResponse) {
  if (sessionCache.length > 0 && Date.now() - sessionCacheTime < SESSION_CACHE_TTL) {
    sendResponse({ sessions: sessionCache, cached: true });
    return;
  }
  const tabId = await getActiveDeepSeekTabId();
  if (!tabId) {
    sendResponse({ error: "\u672A\u627E\u5230 DeepSeek \u6807\u7B7E\u9875\uFF0C\u8BF7\u5148\u6253\u5F00 chat.deepseek.com" });
    return;
  }
  try {
    const tpl = await sendToTab(tabId, { type: "EXPORT_ALL" });
    sessionCache = await fetchAllSessions(tabId, tpl.fetchPageRequest);
    sessionCacheTime = Date.now();
    sendResponse({ sessions: sessionCache });
  } catch (error) {
    logger.error("loadAllSessions failed", describeError(error));
    sendResponse({ error: describeError(error) });
  }
}
async function sendToTab(tabId, message) {
  return chrome.tabs.sendMessage(tabId, message);
}
async function proxyRequest(tabId, req) {
  const payload = {
    url: req.url,
    method: req.method,
    body: req.body
  };
  const result = await sendToTab(tabId, {
    type: "FETCH_PROXY",
    payload
  });
  if (result?.error) {
    logger.error("Proxy request returned error", { url: req.url, method: req.method, error: result.error });
    throw new Error(result.error.replace(/^Error:\s*/, ""));
  }
  return result.data;
}
async function fetchAllSessions(tabId, fetchPageRequest) {
  const sessions = [];
  const seen = /* @__PURE__ */ new Set();
  let page = 0;
  let attempted = 0;
  const MAX_PAGES = 200;
  let req = fetchPageRequest || {
    kind: "fetchPage",
    url: `${FETCH_PAGE_PATH}?lte_cursor.pinned=false&count=${SESSION_PAGE_SIZE}`,
    method: "GET"
  };
  logger.info("fetchAllSessions start", { url: req.url, method: req.method });
  while (page < MAX_PAGES) {
    let data;
    attempted++;
    try {
      data = await proxyRequest(tabId, req);
    } catch (error) {
      logger.error("fetchAllSessions page failed", { page, url: req.url, error: describeError(error) });
      throw error;
    }
    const structure = { keys: "" };
    const extracted = extractSessions(data, structure);
    if (!extracted) {
      logger.error("fetchAllSessions \u54CD\u5E94\u89E3\u6790\u5931\u8D25\uFF08\u7ED3\u6784\u4E0D\u7B26\uFF09", structure.keys);
      throw new Error("\u4F1A\u8BDD\u5217\u8868\u54CD\u5E94\u7ED3\u6784\u65E0\u6CD5\u89E3\u6790");
    }
    const pageSessions = extracted.sessions;
    if (pageSessions.length === 0) {
      logger.info("fetchAllSessions reached end (empty page)", { page, total: sessions.length });
      break;
    }
    const before = sessions.length;
    for (const s of pageSessions) {
      if (!seen.has(s.id)) {
        seen.add(s.id);
        sessions.push(s);
      }
    }
    const added = sessions.length - before;
    logger.info("fetchAllSessions page done", {
      page,
      got: pageSessions.length,
      added,
      total: sessions.length
    });
    broadcastListProgress(sessions.length);
    if (added === 0) {
      logger.info("fetchAllSessions reached end (no new sessions)", { page, total: sessions.length });
      break;
    }
    const last = pageSessions[pageSessions.length - 1];
    const lastUpdated = last?.updated_at;
    if (typeof lastUpdated !== "number" && typeof lastUpdated !== "string") {
      logger.warn("fetchAllSessions \u65E0\u6CD5\u6784\u9020\u4E0B\u4E00\u9875\u6E38\u6807\uFF08\u672B\u6761\u7F3A updated_at\uFF09\uFF0C\u505C\u6B62\u7FFB\u9875", {
        lastKeys: Object.keys(last || {}).join(",")
      });
      break;
    }
    req = {
      ...req,
      url: upsertQueryParam(
        upsertQueryParam(req.url, "lte_cursor.updated_at", String(lastUpdated)),
        "lte_cursor.pinned",
        String(Boolean(last?.pinned))
      )
    };
    page++;
    await sleep(300);
  }
  logger.info("fetchAllSessions finished", { total: sessions.length, pages: attempted });
  return sessions;
}
function upsertQueryParam(url, key, value) {
  try {
    const u = new URL(url, "https://chat.deepseek.com");
    u.searchParams.set(key, value);
    return u.pathname + u.search;
  } catch {
    const sep = url.includes("?") ? "&" : "?";
    return `${url}${sep}${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
  }
}
function buildHistoryRequest(historyReq, sessionId) {
  if (!historyReq) {
    return {
      kind: "history",
      url: `${API_BASE}/api/v0/chat/history_messages?chat_session_id=${encodeURIComponent(sessionId)}`,
      method: "GET"
    };
  }
  try {
    const u = new URL(historyReq.url, "https://chat.deepseek.com");
    u.searchParams.set("chat_session_id", sessionId);
    u.searchParams.delete("cache_version");
    u.searchParams.delete("cache_reset_at");
    return {
      kind: "history",
      url: u.pathname + u.search,
      method: historyReq.method,
      body: historyReq.body ? JSON.stringify({ ...JSON.parse(historyReq.body), chat_session_id: sessionId }) : void 0
    };
  } catch {
    return { kind: "history", url: historyReq.url, method: historyReq.method, body: historyReq.body };
  }
}
async function fetchHistoryMessages(tabId, sessionId, historyRequest) {
  const req = buildHistoryRequest(historyRequest, sessionId);
  try {
    const data = await proxyRequest(tabId, req);
    const structure = { keys: "" };
    const messages = extractMessages(data, structure);
    if (!messages) {
      logger.error("fetchHistoryMessages \u54CD\u5E94\u89E3\u6790\u5931\u8D25\uFF08\u7ED3\u6784\u4E0D\u7B26\uFF09", structure.keys);
      return null;
    }
    logger.debug("fetchHistoryMessages done", { sessionId, count: messages.length });
    return messages;
  } catch (error) {
    logger.error("fetchHistoryMessages failed", { sessionId, url: req.url, error: describeError(error) });
    return null;
  }
}
async function exportCurrentConversation(sendResponse) {
  const tabId = await getActiveDeepSeekTabId();
  if (!tabId) {
    logger.warn("exportCurrent: no DeepSeek tab");
    sendResponse({ error: "\u672A\u627E\u5230 DeepSeek \u6807\u7B7E\u9875\uFF0C\u8BF7\u5148\u6253\u5F00 chat.deepseek.com" });
    return;
  }
  try {
    exportInProgress = true;
    exportProgress = 0;
    logger.info("exportCurrent start", { tabId });
    const sessionData = await sendToTab(tabId, { type: "EXPORT_CURRENT" });
    if (sessionData.error) {
      sendResponse(sessionData);
      return;
    }
    const sessionId = sessionData.sessionId;
    const proxied = await fetchHistoryMessages(tabId, sessionId, sessionData.historyRequest);
    const captured = sessionData.messages || [];
    const messages = proxied && proxied.length > 0 ? proxied : captured.length > 0 ? captured : proxied || [];
    logger.info("exportCurrent history ready", {
      sessionId,
      source: proxied && proxied.length > 0 ? "proxy" : "captured",
      count: messages.length
    });
    let sessionInfo = null;
    try {
      const list = await fetchAllSessions(tabId, sessionData.fetchPageRequest);
      sessionInfo = list.find((s) => s.id === sessionId) || null;
      logger.info("exportCurrent session info", {
        found: Boolean(sessionInfo),
        title: sessionInfo?.title || ""
      });
    } catch (error) {
      logger.error("exportCurrent fetch session info failed", describeError(error));
    }
    const conversation = buildConversation(
      sessionInfo || { id: sessionId, title: "Exported Conversation" },
      messages,
      (_msg, sample) => {
        logger.error("\u6D88\u606F\u6B63\u6587\u63D0\u53D6\u5931\u8D25\uFF08\u6D88\u606F\u7ED3\u6784\u6837\u672C\uFF09", sample);
      }
    );
    const exportData = buildExportJSON([conversation]);
    const filename = generateFilename(`deepseek-session-${sessionId.slice(0, 8)}`);
    await triggerDownload(exportData, filename, tabId);
    logger.info("exportCurrent download triggered", { filename });
    exportInProgress = false;
    exportProgress = 100;
    exportCurrent = null;
    sendResponse({ success: true, filename });
  } catch (error) {
    exportInProgress = false;
    exportProgress = 0;
    exportCurrent = null;
    logger.error("exportCurrent failed", describeError(error));
    sendResponse({ error: describeError(error) });
  }
}
async function exportSelectedConversations(sessionIds, sendResponse) {
  const tabId = await getActiveDeepSeekTabId();
  if (!tabId) {
    logger.warn("exportSelected: no DeepSeek tab");
    sendResponse({ error: "\u672A\u627E\u5230 DeepSeek \u6807\u7B7E\u9875\uFF0C\u8BF7\u5148\u6253\u5F00 chat.deepseek.com" });
    return;
  }
  if (!sessionIds || sessionIds.length === 0) {
    sendResponse({ error: "\u672A\u9009\u62E9\u4EFB\u4F55\u4F1A\u8BDD" });
    return;
  }
  try {
    exportInProgress = true;
    exportProgress = 0;
    logger.info("exportSelected start", { tabId, count: sessionIds.length });
    const tpl = await sendToTab(tabId, { type: "EXPORT_ALL" });
    let source = sessionCache;
    const missing = sessionIds.filter((id) => !source.some((s) => s.id === id));
    if (missing.length > 0) {
      logger.info("exportSelected: cache missing ids, reloading list", { missing: missing.length });
      source = await fetchAllSessions(tabId, tpl.fetchPageRequest);
      sessionCache = source;
      sessionCacheTime = Date.now();
    }
    const selected = sessionIds.map((id) => source.find((s) => s.id === id)).filter((s) => Boolean(s));
    if (selected.length === 0) {
      sendResponse({ error: "\u672A\u627E\u5230\u6240\u9009\u4F1A\u8BDD\uFF0C\u8BF7\u5237\u65B0\u5217\u8868\u540E\u91CD\u8BD5" });
      return;
    }
    const conversations = [];
    const totalSessions = selected.length;
    const failed = [];
    for (let i = 0; i < selected.length; i++) {
      const session = selected[i];
      exportProgress = Math.round(i / totalSessions * 100);
      exportCurrent = { index: i + 1, total: totalSessions, title: session.title || "Untitled" };
      try {
        const result = chrome.runtime.sendMessage({
          type: "EXPORT_PROGRESS",
          payload: {
            progress: exportProgress,
            current: i + 1,
            total: totalSessions,
            title: session.title || "Untitled"
          }
        });
        if (result && typeof result.catch === "function") {
          result.catch(() => {
          });
        }
      } catch (error) {
      }
      try {
        const historyData = await fetchHistoryMessages(tabId, session.id, tpl.historyRequest);
        if (historyData) {
          const conversation = buildConversation(session, historyData, (_msg, sample) => {
            logger.error("\u6D88\u606F\u6B63\u6587\u63D0\u53D6\u5931\u8D25\uFF08\u6D88\u606F\u7ED3\u6784\u6837\u672C\uFF09", { sessionId: session.id, sample });
          });
          conversations.push(conversation);
          logger.debug("exportSelected session ok", {
            i,
            id: session.id,
            messages: historyData.length
          });
        } else {
          failed.push(session.id);
          logger.warn("exportSelected session empty history", { i, id: session.id });
        }
        if ((i + 1) % 5 === 0 && i < selected.length - 1) {
          await sleep(800);
        }
      } catch (error) {
        failed.push(session.id);
        logger.error("exportSelected session failed", { i, id: session.id, error: describeError(error) });
      }
    }
    const exportData = buildExportJSON(conversations);
    const filename = generateFilename(
      selected.length > 3 ? "deepseek-conversations" : `deepseek-conversations-${selected.length}`
    );
    await triggerDownload(exportData, filename, tabId);
    logger.info("exportSelected download triggered", {
      filename,
      conversations: conversations.length,
      failed: failed.length
    });
    exportInProgress = false;
    exportProgress = 100;
    exportCurrent = null;
    sendResponse({ success: true, filename, count: conversations.length });
  } catch (error) {
    exportInProgress = false;
    exportProgress = 0;
    exportCurrent = null;
    logger.error("exportSelected failed", describeError(error));
    sendResponse({ error: describeError(error) });
  }
}
async function deleteSessions(sessionIds, sendResponse) {
  if (!deleteTemplate) {
    sendResponse({
      error: "\u5220\u9664\u63A5\u53E3\u5C1A\u672A\u5B66\u4E60\uFF1A\u8BF7\u5148\u5728 DeepSeek \u9875\u9762\u4E0A\u624B\u52A8\u5220\u9664\u4EFB\u610F\u4E00\u4E2A\u4F1A\u8BDD\uFF0C\u6269\u5C55\u4F1A\u81EA\u52A8\u6355\u83B7\u8BE5\u64CD\u4F5C\uFF0C\u4E4B\u540E\u5373\u53EF\u6279\u91CF\u5220\u9664"
    });
    return;
  }
  const tabId = await getActiveDeepSeekTabId();
  if (!tabId) {
    sendResponse({ error: "\u672A\u627E\u5230 DeepSeek \u6807\u7B7E\u9875\uFF0C\u8BF7\u5148\u6253\u5F00 chat.deepseek.com" });
    return;
  }
  if (!sessionIds || sessionIds.length === 0) {
    sendResponse({ error: "\u672A\u9009\u62E9\u4EFB\u4F55\u4F1A\u8BDD" });
    return;
  }
  try {
    exportInProgress = true;
    exportProgress = 0;
    logger.warn("deleteSessions start\uFF08\u4E0D\u53EF\u9006\u64CD\u4F5C\uFF09", {
      count: sessionIds.length,
      url: deleteTemplate.url,
      method: deleteTemplate.method
    });
    const total = sessionIds.length;
    let ok = 0;
    const failed = [];
    for (let i = 0; i < sessionIds.length; i++) {
      const id = sessionIds[i];
      exportProgress = Math.round(i / total * 100);
      exportCurrent = { index: i + 1, total, title: `\u5220\u9664 ${id.slice(0, 8)}` };
      try {
        const delReq = buildDeleteRequest(deleteTemplate, [id]);
        await proxyRequest(tabId, delReq);
        ok++;
        sessionCache = sessionCache.filter((s) => s.id !== id);
        logger.info("deleteSessions deleted", { i, id });
      } catch (error) {
        failed.push(id);
        logger.error("deleteSessions failed", { i, id, error: describeError(error) });
      }
      try {
        const result = chrome.runtime.sendMessage({
          type: "EXPORT_PROGRESS",
          payload: {
            progress: exportProgress,
            current: i + 1,
            total,
            title: `\u5220\u9664 ${id.slice(0, 8)}`
          }
        });
        if (result && typeof result.catch === "function") {
          result.catch(() => {
          });
        }
      } catch {
      }
      if ((i + 1) % 5 === 0 && i < total - 1) {
        await sleep(800);
      }
    }
    exportInProgress = false;
    exportProgress = 100;
    exportCurrent = null;
    logger.warn("deleteSessions finished", { ok, failed: failed.length });
    sendResponse({ success: true, ok, failed: failed.length });
  } catch (error) {
    exportInProgress = false;
    exportProgress = 0;
    exportCurrent = null;
    logger.error("deleteSessions failed", describeError(error));
    sendResponse({ error: describeError(error) });
  }
}
function buildDeleteRequest(template, sessionIds) {
  let body = template.body;
  if (body) {
    try {
      const replaced = replaceUuids(JSON.parse(body), sessionIds);
      body = JSON.stringify(replaced);
    } catch (error) {
      logger.error("\u5220\u9664\u6A21\u677F body \u89E3\u6790\u5931\u8D25", describeError(error));
    }
  }
  return { kind: "delete", url: template.url, method: template.method, body };
}
function replaceUuids(node, sessionIds) {
  if (typeof node === "string") {
    return UUID_RE.test(node) ? sessionIds[0] : node;
  }
  if (Array.isArray(node)) {
    if (node.some((x) => typeof x === "string" && UUID_RE.test(x))) {
      return sessionIds;
    }
    return node.map((x) => replaceUuids(x, sessionIds));
  }
  if (typeof node === "object" && node !== null) {
    const out = {};
    for (const [k, v] of Object.entries(node)) {
      out[k] = replaceUuids(v, sessionIds);
    }
    return out;
  }
  return node;
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
chrome.runtime.onInstalled.addListener((details) => {
  logger.info("Extension installed/updated", {
    reason: details.reason,
    version: chrome.runtime.getManifest().version
  });
});
self.addEventListener("unhandledrejection", (e) => {
  const reason = e.reason instanceof Error ? `${e.reason.message}
${e.reason.stack || ""}` : String(e.reason);
  logger.error("\u672A\u5904\u7406\u7684 Promise rejection", reason.slice(0, 1e3));
});
